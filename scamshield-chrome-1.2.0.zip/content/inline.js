// Inline warnings for WhatsApp Web and Gmail. Registered only while the user has switched them on.
// Reads the messages already shown on the page, asks the extension's background worker to analyze them
// (nothing leaves the browser), and adds a small badge next to risky ones. Clicking the badge explains why.
(() => {
    'use strict';
    if (globalThis.__scamshieldInline) { globalThis.__scamshieldInline.rescan(); return; }

    const SOURCE = { 'web.whatsapp.com': 'WHATSAPP', 'mail.google.com': 'EMAIL' }[location.hostname] ?? globalThis.__SCAMSHIELD_TEST_SOURCE__;
    if (!SOURCE) return;

    const MAX_LENGTH = 10_000;
    const CATEGORY_LABEL = { LOW: 'Low risk', MEDIUM: 'Medium risk', HIGH: 'High risk', CRITICAL: 'Critical risk' };
    const PATTERN_LABEL = {
        NONE: 'No specific scam pattern', SUSPICIOUS: 'General suspicious message', KYC_PHISHING: 'KYC / account-block phishing',
        CREDENTIAL_THEFT: 'OTP / password theft', UPI_FRAUD: 'UPI payment fraud', REMOTE_ACCESS: 'Remote-access / malicious app',
        LOTTERY_PRIZE: 'Lottery / prize / cashback lure', JOB_TASK: 'Part-time job / task scam', INVESTMENT: 'Investment / trading scam',
        LOAN: 'Instant loan scam', DIGITAL_ARREST: 'Digital arrest / authority threat', UTILITY_DISCONNECTION: 'Electricity / utility disconnection scam',
        FAMILY_IMPERSONATION: 'Friend or family impersonation', PHISHING_LINK: 'Phishing link',
    };

    let handled = new WeakMap();   // message element -> key of the text last analyzed
    const badges = new Map();      // message element -> badge host element
    const dismissed = new Set();   // keys the user dismissed on this page
    let observer = null;
    let timer = null;
    let running = false;

    // ------------------------------------------------------------ Site adapters
    // Each returns the messages currently on screen: { el, text, details, place(host) }.

    const PHONE = /^\+?[\d\s()\-]{8,}$/;

    function whatsappMessages() {
        const items = [];
        for (const copy of document.querySelectorAll('.message-in .copyable-text[data-pre-plain-text]')) {
            const bubble = copy.closest('.message-in');
            const text = (copy.querySelector('span.selectable-text') ?? copy).innerText.trim();
            if (!bubble || text.length < 8) continue;
            // "[10:42, 27/10/2026] +91 98765 43210: " - unsaved contacts show a number instead of a name.
            const sender = (/^\[[^\]]*\]\s*(.*?):\s*$/.exec(copy.getAttribute('data-pre-plain-text') ?? '') ?? [])[1] ?? '';
            const isNumber = PHONE.test(sender);
            items.push({
                el: bubble, text: text.slice(0, MAX_LENGTH),
                details: { source: 'WHATSAPP', senderNumber: isNumber ? sender : '', unknownContact: isNumber, forwardedManyTimes: /forwarded many times/i.test(bubble.textContent) },
                place: host => copy.parentElement.append(host),
            });
        }
        return items;
    }

    /** Gmail wraps links as https://www.google.com/url?q=<real link>; unwrap them. */
    function realHref(href) {
        try {
            const u = new URL(href);
            if (/(^|\.)google\.com$/.test(u.hostname) && u.pathname === '/url') return u.searchParams.get('q') ?? u.searchParams.get('url') ?? href;
            return href;
        } catch { return ''; }
    }

    function gmailMessages() {
        const items = [];
        const subject = document.querySelector('h2.hP')?.innerText.trim() ?? '';
        for (const body of document.querySelectorAll('div.a3s')) {
            if (body.parentElement?.closest('div.a3s')) continue;
            const message = body.closest('.adn, .gs') ?? body.parentElement;
            const from = message?.querySelector('span.gD[email]');
            const fromAddress = from ? `${from.getAttribute('name') || from.innerText.trim()} <${from.getAttribute('email')}>` : '';
            let text = body.innerText.trim();
            // Phishing mail hides the real address behind link text, so the link targets are checked too.
            const hidden = [...new Set([...body.querySelectorAll('a[href]')].map(a => realHref(a.href)))]
                .filter(h => /^https?:/i.test(h) && !text.includes(h));
            if (hidden.length > 0) text += '\n\nLinks in this email:\n' + hidden.slice(0, 20).join('\n');
            if (text.length < 8) continue;
            items.push({
                el: body, text: text.slice(0, MAX_LENGTH),
                details: { source: 'EMAIL', fromAddress, subject },
                place: host => body.before(host),
            });
        }
        return items;
    }

    const messagesOnPage = SOURCE === 'WHATSAPP' ? whatsappMessages : gmailMessages;

    // ------------------------------------------------------------ Scanning

    function hash(s) {
        let h = 0x811c9dc5;
        for (let i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 0x01000193); }
        return (h >>> 0).toString(36) + ':' + s.length;
    }

    async function scan() {
        if (running) { schedule(); return; }
        running = true;
        try {
            for (const item of messagesOnPage()) {
                const key = hash(item.text + '\u0000' + JSON.stringify(item.details));
                if (handled.get(item.el) === key) continue;
                handled.set(item.el, key);
                removeBadge(item.el);
                if (dismissed.has(key)) continue;
                let response;
                try {
                    response = await chrome.runtime.sendMessage({ type: 'scamshield:analyze', source: SOURCE, text: item.text, details: item.details });
                } catch {
                    teardown(); // the extension was reloaded or removed
                    return;
                }
                if (response?.disabled) { teardown(); return; }
                if (response?.ok && response.show && item.el.isConnected) addBadge(item, response.result, key);
            }
        } finally {
            running = false;
        }
    }

    function schedule() {
        clearTimeout(timer);
        timer = setTimeout(scan, 700);
    }

    function start() {
        if (observer) return;
        observer = new MutationObserver(schedule);
        observer.observe(document.body, { childList: true, subtree: true, characterData: true });
        schedule();
    }

    function teardown() {
        observer?.disconnect();
        observer = null;
        clearTimeout(timer);
        for (const el of [...badges.keys()]) removeBadge(el);
        handled = new WeakMap();
    }

    function removeBadge(el) {
        badges.get(el)?.remove();
        badges.delete(el);
    }

    // ------------------------------------------------------------ Badge UI (Shadow DOM, so page styles cannot leak in)

    const STYLE = `
        :host { all: initial; display: block; margin: 6px 0 2px; font: 13px/1.4 system-ui, "Segoe UI", Roboto, sans-serif; }
        * { box-sizing: border-box; }
        .wrap { --low: #23824e; --medium: #a77500; --high: #c9561a; --critical: #b92828;
                --card: #fff; --text: #122b46; --muted: #5c6a79; --border: #dae2eb; --soft: #f4f7fa; color: var(--text); }
        @media (prefers-color-scheme: dark) {
            .wrap { --low: #4cbb7f; --medium: #e0aa2e; --high: #ee8a4f; --critical: #f06464;
                    --card: #17212c; --text: #e4ebf2; --muted: #97a6b5; --border: #2a3846; --soft: #0f1720; }
        }
        .wrap[data-risk="LOW"] { --sev: var(--low); } .wrap[data-risk="MEDIUM"] { --sev: var(--medium); }
        .wrap[data-risk="HIGH"] { --sev: var(--high); } .wrap[data-risk="CRITICAL"] { --sev: var(--critical); }
        button { font: inherit; cursor: pointer; }
        .pill { display: inline-flex; align-items: center; gap: 6px; border: 1px solid var(--sev); color: var(--sev);
                background: var(--card); border-radius: 999px; padding: 3px 10px 3px 6px; font-weight: 600; max-width: 100%; }
        .pill:hover { background: var(--soft); }
        .pill svg { flex: none; }
        .pill .sub { color: var(--muted); font-weight: 400; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
        .pop { margin-top: 6px; background: var(--card); border: 1px solid var(--border); border-left: 4px solid var(--sev);
               border-radius: 10px; padding: 10px 12px; max-width: 420px; box-shadow: 0 6px 20px rgba(0,0,0,.12); }
        .pop[hidden] { display: none; }
        .pattern { margin: 0 0 6px; font-weight: 600; }
        ul { margin: 0 0 8px; padding: 0; list-style: none; display: grid; gap: 5px; }
        li b { display: block; }
        li span { color: var(--muted); font-size: 12px; font-style: italic; word-break: break-word; }
        .advice { margin: 0 0 8px; padding: 8px; background: var(--soft); border-radius: 6px; font-size: 12.5px; }
        .row { display: flex; gap: 6px; flex-wrap: wrap; }
        .row button { border-radius: 7px; padding: 5px 10px; border: 1px solid var(--border); background: transparent; color: var(--text); font-weight: 600; }
        .row button.primary { background: var(--sev); border-color: var(--sev); color: #fff; }
        .foot { margin: 8px 0 0; color: var(--muted); font-size: 11px; }
        button:focus-visible { outline: 2px solid var(--sev); outline-offset: 2px; }
    `;

    function node(tag, props = {}, ...children) {
        const n = document.createElement(tag);
        Object.assign(n, props);
        n.append(...children.filter(c => c != null));
        return n;
    }

    /** Built with DOM calls rather than innerHTML, which Gmail's Trusted Types policy would block. */
    function shieldIcon() {
        const NS = 'http://www.w3.org/2000/svg';
        const el = (tag, attrs) => { const n = document.createElementNS(NS, tag); for (const [k, v] of Object.entries(attrs)) n.setAttribute(k, v); return n; };
        const svg = el('svg', { viewBox: '0 0 20 20', width: '16', height: '16', 'aria-hidden': 'true' });
        svg.append(el('path', { d: 'M10 1.5 3 4v5.2c0 4.3 3 7.6 7 9.3 4-1.7 7-5 7-9.3V4z', fill: 'currentColor' }),
            el('path', { d: 'M10 5.5v5M10 13.2v.3', stroke: '#fff', 'stroke-width': '2', 'stroke-linecap': 'round' }));
        return svg;
    }

    let sheet = null;
    /** A constructable stylesheet is not blocked by a page's style-src policy, unlike a <style> element. */
    function badgeSheet() {
        if (!sheet) { sheet = new CSSStyleSheet(); sheet.replaceSync(STYLE); }
        return sheet;
    }

    function addBadge(item, result, key) {
        const host = document.createElement('div');
        host.setAttribute('data-scamshield', '');
        // Keep clicks inside the badge from opening the site's own message menus.
        for (const type of ['click', 'mousedown', 'mouseup', 'keydown', 'contextmenu']) host.addEventListener(type, e => e.stopPropagation());
        const root = host.attachShadow({ mode: 'closed' });
        const pattern = PATTERN_LABEL[result.scamType] ?? result.scamType;

        const pop = node('div', { className: 'pop', hidden: true, role: 'dialog', ariaLabel: 'ScamShield warning' },
            node('p', { className: 'pattern', textContent: `Likely pattern: ${pattern} · score ${result.score}/100` }),
            node('ul', {}, ...result.indicators.slice(0, 4).map(i =>
                node('li', {}, node('b', { textContent: i.title }), i.evidence.snippet ? node('span', { textContent: `“${i.evidence.snippet}”` }) : null))),
            node('p', { className: 'advice', textContent: result.recommendations.find(a => !a.startsWith('If you have already paid')) ?? result.recommendations[0] }),
            node('div', { className: 'row' },
                node('button', { className: 'primary', type: 'button', textContent: 'Full analysis', onclick: () => chrome.runtime.sendMessage({ type: 'scamshield:open', source: SOURCE, text: item.text, details: item.details }).catch(() => { }) }),
                node('button', { type: 'button', textContent: 'Dismiss', onclick: () => { dismissed.add(key); removeBadge(item.el); } })),
            node('p', { className: 'foot', textContent: 'ScamShield checked this on your device. It is a warning, not proof.' }));

        const pill = node('button', { className: 'pill', type: 'button', ariaExpanded: 'false', title: 'ScamShield: click for details' },
            shieldIcon(), node('span', { textContent: `${CATEGORY_LABEL[result.category]} · ${result.score}` }), node('span', { className: 'sub', textContent: pattern }));
        pill.addEventListener('click', () => {
            pop.hidden = !pop.hidden;
            pill.setAttribute('aria-expanded', String(!pop.hidden));
        });

        const wrap = node('div', { className: 'wrap' }, pill, pop);
        wrap.dataset.risk = result.category;
        root.adoptedStyleSheets = [badgeSheet()];
        root.append(wrap);
        item.place(host);
        badges.set(item.el, host);
    }

    // ------------------------------------------------------------ Settings

    chrome.storage?.onChanged.addListener((changes, area) => {
        if (area !== 'local' || !changes.settings) return;
        const next = changes.settings.newValue ?? {};
        if (next.inline?.[SOURCE] !== true) { teardown(); return; }
        // Level, weights or trusted lists changed: analyze everything again.
        teardown();
        start();
    });

    globalThis.__scamshieldInline = { rescan: () => { teardown(); start(); } };
    start();
})();
