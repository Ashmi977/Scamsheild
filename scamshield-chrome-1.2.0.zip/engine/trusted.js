/**
 * The user's own trusted senders and domains (extension-only; the Java engine has no equivalent).
 * A trusted entry only skips the checks about who sent the message or where a link points.
 * The message text is always checked, because trusted accounts can be hacked or imitated.
 */

export const EMPTY_TRUSTED = Object.freeze({ smsSenders: [], whatsappNumbers: [], upiIds: [], emailDomains: [], linkDomains: [] });

const SMS_HEADER = /^(?:[A-Z]{2}-)?([A-Z0-9]{3,9})(?:-[SPTG])?$/i;

/** "+91 98765 43210", "09876543210", "0091…" and "9876543210" all become "+919876543210". */
export function normalizePhone(value) {
    let n = String(value ?? '').replace(/[\s()\-.]/g, '');
    if (n.startsWith('00')) n = '+' + n.substring(2);
    if (/^0[6-9]\d{9}$/.test(n)) n = n.substring(1);
    if (/^[6-9]\d{9}$/.test(n)) n = '+91' + n;
    if (/^91[6-9]\d{9}$/.test(n)) n = '+' + n;
    return n;
}

/** Lower-case host from "https://www.example.com/path", "@example.com" or "example.com". */
export function normalizeDomain(value) {
    return String(value ?? '').trim().toLowerCase()
        .replace(/^[a-z]+:\/\//, '').replace(/^.*@/, '').replace(/[/?#:].*$/, '').replace(/^www\./, '').replace(/\.+$/, '');
}

/** "AX-HDFCBK-S" and "HDFCBK" both become "HDFCBK"; phone numbers are normalized instead. */
function smsKey(value) {
    const v = String(value ?? '').trim();
    if (/^\+?[\d\s()\-.]{8,}$/.test(v)) return normalizePhone(v);
    const m = SMS_HEADER.exec(v);
    return m ? m[1].toUpperCase() : v.toUpperCase();
}

const domainMatches = (host, domain) => domain !== '' && (host === domain || host.endsWith('.' + domain));

/** Cleans a user-edited trusted list object; unknown keys and blank lines are dropped. */
export function normalizeTrusted(raw = {}) {
    const list = (values, fn) => [...new Set((Array.isArray(values) ? values : []).map(fn).filter(v => v.length > 0))];
    return {
        smsSenders: list(raw.smsSenders, v => String(v).trim()),
        whatsappNumbers: list(raw.whatsappNumbers, v => String(v).trim()),
        upiIds: list(raw.upiIds, v => String(v).trim().toLowerCase()),
        emailDomains: list(raw.emailDomains, normalizeDomain),
        linkDomains: list(raw.linkDomains, normalizeDomain),
    };
}

export const isTrustedSmsSender = (trusted, sender) => sender !== '' && trusted.smsSenders.some(e => smsKey(e) === smsKey(sender));
export const isTrustedWhatsApp = (trusted, number) => number !== '' && trusted.whatsappNumbers.some(e => normalizePhone(e) === normalizePhone(number));
export const isTrustedUpi = (trusted, vpa) => vpa !== '' && trusted.upiIds.includes(vpa.toLowerCase());
export const isTrustedEmailDomain = (trusted, domain) => trusted.emailDomains.some(d => domainMatches(domain, d));
export const isTrustedLinkHost = (trusted, host) => trusted.linkDomains.some(d => domainMatches(host, d));
