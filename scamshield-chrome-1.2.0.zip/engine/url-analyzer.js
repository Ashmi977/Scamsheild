/**
 * Offline inspection of links found in a message. No network request is ever made: only the
 * structure of the address is examined.
 */
import { imitatedBy, isTrustedHost } from './brands.js';

/** Declaration order is the order reasons are listed in. */
export const URL_RISKS = {
    SHORTENER: 'uses a link-shortening service',
    IP_ADDRESS: 'points to a raw IP address instead of a domain name',
    PUNYCODE: 'uses an internationalized (punycode) domain that can imitate familiar letters',
    RISKY_TLD: 'uses a low-cost domain ending often abused for phishing',
    AT_SIGN: "contains an '@' that hides the real destination",
    MANY_SUBDOMAINS: 'has an unusually deep chain of subdomains',
    APK_FILE: 'downloads an Android .apk file',
    LOOKALIKE: 'borrows a brand name in a domain the brand does not own',
    CHAT_INVITE: 'invites you to a WhatsApp or Telegram chat',
};

const COMMON_TLDS = 'com|in|net|org|co|io|info|biz|me|ly|gl|gy|to|it|at|id|cc|xyz|top|click|live|buzz|icu|cyou|sbs|cfd|rest|monster|online|site|fun|vip|win|loan|work|support|shop|store|app|link|club';
const URL = new RegExp(String.raw`\b(?:https?://|www\.)[^\s<>"']+`
    + String.raw`|(?<![@\w.-])(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+(?:` + COMMON_TLDS + String.raw`)(?::\d{2,5})?(?:/[^\s<>"']*)?(?![\w@-])`, 'gi');
const IPV4 = /^\d{1,3}(?:\.\d{1,3}){3}$/;
const SHORTENERS = new Set(['bit.ly', 'bitly.com', 'tinyurl.com', 't.co', 'goo.gl', 'rb.gy', 'cutt.ly', 'is.gd',
    'ow.ly', 'shorturl.at', 'tiny.cc', 't.ly', 's.id', 'rebrand.ly', 'v.gd', 'short.gy', 'shorturl.ly', 'tny.im', 'surl.li', 'u.to']);
const RISKY_TLDS = new Set(['xyz', 'top', 'click', 'live', 'buzz', 'icu', 'cyou', 'sbs', 'cfd', 'rest', 'monster',
    'online', 'site', 'fun', 'vip', 'win', 'loan', 'work', 'support', 'link', 'club']);
const CHAT_HOSTS = new Set(['wa.me', 'chat.whatsapp.com', 't.me', 'telegram.me', 'telegram.dog']);

/**
 * @param isUserTrusted host => true for domains on the user's own trusted list; such links get no risks
 * @returns {{url, host, evidence, risks: Set<string>, imitatedBrand, trusted: boolean, userTrusted: boolean}[]}
 */
export function analyzeUrls(text, isUserTrusted = () => false) {
    const findings = [];
    for (const m of text.value.matchAll(URL)) {
        const raw = trimTrailingPunctuation(m[0]);
        if (!/\p{L}/u.test(raw)) continue;
        const h = host(raw);
        if (h.length === 0 || !h.includes('.')) continue;
        if (isUserTrusted(h)) {
            findings.push({ url: raw, host: h, evidence: text.evidence(m.index, m.index + raw.length), risks: new Set(), imitatedBrand: null, trusted: true, userTrusted: true });
            continue;
        }
        const risks = new Set();
        const lower = raw.toLowerCase();
        if (SHORTENERS.has(h)) risks.add('SHORTENER');
        if (IPV4.test(h)) risks.add('IP_ADDRESS');
        if (h.includes('xn--')) risks.add('PUNYCODE');
        if (RISKY_TLDS.has(h.substring(h.lastIndexOf('.') + 1))) risks.add('RISKY_TLD');
        if (authority(lower).includes('@')) risks.add('AT_SIGN');
        if (h.split('.').length >= 5) risks.add('MANY_SUBDOMAINS');
        if (/\.apk(?:[?#].*)?$/s.test(lower) || lower.includes('.apk?') || lower.includes('.apk/')) risks.add('APK_FILE');
        if (CHAT_HOSTS.has(h)) risks.add('CHAT_INVITE');
        const imitated = imitatedBy(h);
        if (imitated) risks.add('LOOKALIKE');
        findings.push({
            url: raw, host: h, evidence: text.evidence(m.index, m.index + raw.length),
            risks, imitatedBrand: imitated, trusted: isTrustedHost(h), userTrusted: false,
        });
    }
    return findings;
}

/** Lower-case host name without scheme, credentials, port, path or a leading "www.". */
export function host(url) {
    let a = authority(url.toLowerCase());
    const at = a.lastIndexOf('@');
    if (at >= 0) a = a.substring(at + 1);
    const colon = a.indexOf(':');
    if (colon >= 0) a = a.substring(0, colon);
    if (a.startsWith('www.')) a = a.substring(4);
    return a.replace(/\.+$/, '');
}

function authority(url) {
    const rest = url.replace(/^[a-z]+:\/\//, '');
    let end = rest.length;
    for (const c of ['/', '?', '#']) { const i = rest.indexOf(c); if (i >= 0 && i < end) end = i; }
    return rest.substring(0, end);
}

function trimTrailingPunctuation(url) {
    let end = url.length;
    while (end > 0 && `.,;:!?)]}'"`.includes(url.charAt(end - 1))) end--;
    return url.substring(0, end);
}
