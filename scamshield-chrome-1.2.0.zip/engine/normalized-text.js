/**
 * Message text prepared for matching: Unicode-normalized (NFKC), invisible characters removed and
 * typographic quotes/dashes replaced with ASCII. Keeps a map back to the original offsets so that
 * evidence can be highlighted in exactly what the user typed.
 */

const MAX_SNIPPET = 90;

export const NO_EVIDENCE = Object.freeze({ snippet: '', start: -1, end: -1 });

/** Evidence that comes from metadata (sender, subject) rather than the message text. */
export function metadataEvidence(value) { return { snippet: value, start: -1, end: -1 }; }

export function inText(evidence) { return evidence.start >= 0 && evidence.end > evidence.start; }

function map(cp) {
    if (cp === 0x200B || cp === 0x200C || cp === 0x200D || cp === 0x2060 || cp === 0xFEFF || cp === 0x00AD) return '';
    if (cp === 0x2018 || cp === 0x2019 || cp === 0x201B || cp === 0x2032) return "'";
    if (cp === 0x201C || cp === 0x201D || cp === 0x2033) return '"';
    if (cp >= 0x2010 && cp <= 0x2015) return '-';
    const s = String.fromCodePoint(cp).normalize('NFKC');
    return s.length === 0 ? ' ' : s;
}

export class NormalizedText {
    constructor(original) {
        this.original = original;
        let out = '';
        const starts = [], ends = [];
        for (let i = 0; i < original.length;) {
            const cp = original.codePointAt(i);
            const next = i + (cp > 0xFFFF ? 2 : 1);
            const mapped = map(cp);
            for (let k = 0; k < mapped.length; k++) { starts.push(i); ends.push(next); }
            out += mapped;
            i = next;
        }
        this.value = out;
        this.originalStart = starts;
        this.originalEnd = ends;
    }

    /** Converts a [start, end) range of the normalized text into evidence over the original text. */
    evidence(start, end) {
        if (start < 0 || end <= start || end > this.value.length) return NO_EVIDENCE;
        const os = this.originalStart[start], oe = this.originalEnd[end - 1];
        let snippet = this.original.substring(os, oe).replace(/\s+/g, ' ').trim();
        if (snippet.length > MAX_SNIPPET) snippet = snippet.substring(0, MAX_SNIPPET - 1) + '…';
        return { snippet, start: os, end: oe };
    }
}
