/** Text rules (every channel), link rules (offline URL inspection) and channel-metadata rules. */
import { RULES as R, UPI_REQUEST_TYPES } from './catalog.js';
import { allBrands, imitatedBy, isTrustedHost } from './brands.js';
import { URL_RISKS } from './url-analyzer.js';
import { metadataEvidence } from './normalized-text.js';
import { matchesMetadata } from './context.js';
import { isTrustedEmailDomain, isTrustedSmsSender, isTrustedUpi, isTrustedWhatsApp } from './trusted.js';
import * as P from './patterns.js';

// ---------------- Text rules ----------------

const pattern = (rule, re) => ctx => { const e = ctx.find(re); return e && ctx.indicator(rule, e); };

/** Fires on the first pattern only when the second also appears somewhere in the message. */
const both = (rule, main, required) => ctx => {
    if (!ctx.has(required)) return null;
    const e = ctx.find(main);
    return e && ctx.indicator(rule, e);
};

function callbackNumber(ctx) {
    const call = ctx.find(P.CALL_MOBILE);
    const claimsAuthority = ctx.mentionsBrand() || ctx.has(P.KYC_THREAT) || ctx.has(P.UTILITY) || ctx.has(P.DIGITAL_ARREST);
    return call && claimsAuthority ? ctx.indicator(R.CALLBACK_NUMBER, call) : null;
}

function impersonation(ctx) {
    if (ctx.brands.length === 0 || !ctx.requestsRiskyAction()) return null;
    const mention = ctx.brands[0];
    return ctx.indicator(R.IMPERSONATION, mention.evidence,
        'The message invokes ' + mention.brand.name + ' while asking you to act. Contact the organization through its official app or website instead.');
}

const TEXT_RULES = [
    ctx => { const e = ctx.credentialRequest(); return e && ctx.indicator(R.CREDENTIAL_REQUEST, e); },
    pattern(R.UPI_RECEIVE_PIN, P.UPI_RECEIVE),
    pattern(R.QR_PAYMENT_DECEPTION, P.QR_DECEPTION),
    pattern(R.SMALL_VERIFICATION_PAYMENT, P.SMALL_VERIFICATION),
    both(R.ACCIDENTAL_TRANSFER, P.ACCIDENTAL_TRANSFER, P.RETURN_REQUEST),
    pattern(R.ADVANCE_FEE, P.ADVANCE_FEE),
    pattern(R.KYC_URGENT_THREAT, P.KYC_THREAT),
    pattern(R.DIGITAL_ARREST, P.DIGITAL_ARREST),
    both(R.UTILITY_DISCONNECTION, P.UTILITY, P.UTILITY_PRESSURE),
    pattern(R.SECRECY_REQUEST, P.SECRECY),
    pattern(R.URGENCY_PRESSURE, P.URGENCY),
    pattern(R.PRIZE_OFFER, P.PRIZE),
    pattern(R.JOB_TASK_OFFER, P.JOB_TASK),
    pattern(R.INVESTMENT_LURE, P.INVESTMENT),
    pattern(R.LOAN_OFFER, P.LOAN),
    both(R.FAMILY_EMERGENCY, P.FAMILY, P.MONEY_REQUEST),
    pattern(R.UNKNOWN_APP, P.UNKNOWN_APP),
    callbackNumber,
    impersonation,
];

// ---------------- Link rules ----------------
// A plain link on its own scores nothing.

const TECHNICAL = ['IP_ADDRESS', 'PUNYCODE', 'RISKY_TLD', 'AT_SIGN', 'MANY_SUBDOMAINS'];
const firstUrl = (ctx, risk) => ctx.urls.find(u => u.risks.has(risk));

function technical(ctx) {
    for (const url of ctx.urls) {
        const reasons = Object.keys(URL_RISKS).filter(r => TECHNICAL.includes(r) && url.risks.has(r)).map(r => URL_RISKS[r]).join('; ');
        if (reasons) return ctx.indicator(R.SUSPICIOUS_URL, url.evidence, 'The link ' + reasons + '.');
    }
    return null;
}

function pressured(ctx) {
    const untrusted = ctx.untrustedUrls();
    if (untrusted.length === 0) return null;
    const pressure = ctx.has(P.LINK_ACTION) || ctx.has(P.KYC_THREAT) || ctx.credentialRequest() !== null;
    return pressure ? ctx.indicator(R.PRESSURED_LINK, untrusted[0].evidence) : null;
}

const LINK_RULES = [
    ctx => { const u = firstUrl(ctx, 'APK_FILE'); return u && ctx.indicator(R.APK_LINK, u.evidence); },
    ctx => {
        const u = firstUrl(ctx, 'LOOKALIKE');
        return u && ctx.indicator(R.LOOKALIKE_DOMAIN, u.evidence,
            "'" + u.host + "' uses the name of " + u.imitatedBrand.name + ' but is not one of its official websites.');
    },
    technical,
    ctx => { const u = firstUrl(ctx, 'SHORTENER'); return u && ctx.indicator(R.SHORT_LINK, u.evidence); },
    pressured,
    ctx => { const u = firstUrl(ctx, 'CHAT_INVITE'); return u && ctx.has(P.CHAT_GROUP_CONTEXT) ? ctx.indicator(R.CHAT_GROUP_LINK, u.evidence) : null; },
];

/** Rules that return at most one indicator each, in evaluation order. */
export const SINGLE_RULES = [...TEXT_RULES, ...LINK_RULES];

// ---------------- Channel rules ----------------
// Use channel metadata; each runs only for its own channel and can report several indicators.

const SMS_HEADER = /^(?:[A-Z]{2}-)?([A-Z0-9]{3,9})(?:-[SPTG])?$/i;
const PHONE = /^\+?\d{10,14}$/;
const VPA = /^[a-z0-9][a-z0-9._-]{1,255}@[a-z][a-z0-9]{1,63}$/i;
const VPA_BAIT = /refund|cashback|reward|prize|kyc|support|care|help|customer|verify|official|gift|lottery|offer|bonus|claim|winner|rbi|govt|police/i;
const FREE_MAIL = new Set(['gmail.com', 'googlemail.com', 'yahoo.com', 'yahoo.co.in', 'outlook.com', 'hotmail.com', 'live.com',
    'rediffmail.com', 'aol.com', 'icloud.com', 'proton.me', 'protonmail.com', 'zohomail.in', 'mail.com', 'gmx.com', 'yandex.com']);
const LARGE_AMOUNT = 10000;

export function detectChannel(ctx) {
    const d = ctx.details;
    switch (d.source) {
        case 'SMS': return sms(ctx, d);
        case 'WHATSAPP': return whatsApp(ctx, d);
        case 'UPI': return upi(ctx, d);
        case 'EMAIL': return email(ctx, d);
    }
    return [];
}

function sms(ctx, { senderId: sender }) {
    const found = [];
    if (!sender) return found;
    if (isTrustedSmsSender(ctx.trusted, sender)) {
        ctx.notes.push(`The sender '${sender}' is on your trusted list, so sender checks were skipped. The message text was still checked.`);
        return found;
    }
    const ev = metadataEvidence('Sender: ' + sender);
    const compact = sender.replace(/[\s()-]/g, '');
    if (PHONE.test(compact)) {
        const named = ctx.brands.filter(b => !b.brand.isGeneric || ctx.requestsRiskyAction());
        if (named.length > 0) found.push(ctx.indicator(R.SMS_PHONE_SENDER_BRAND, ev,
            'The message mentions ' + named[0].brand.name + ' but came from the personal number ' + sender
            + '. Organizations send SMS from registered sender IDs such as AX-HDFCBK-S.'));
        if (ctx.untrustedUrls().length > 0) found.push(ctx.indicator(R.SMS_PHONE_SENDER_LINK, ev));
        return found;
    }
    const header = SMS_HEADER.exec(sender);
    if (header && ctx.requestsRiskyAction()) {
        const claimed = ctx.brands.map(m => m.brand).filter(b => !b.isGeneric);
        if (claimed.length > 0 && !claimed.some(b => b.matchesSmsHeader(header[1]))) {
            found.push(ctx.indicator(R.SMS_HEADER_MISMATCH, ev,
                'The message claims to be from ' + claimed[0].name + ", but the sender ID '" + sender + "' does not belong to it."));
        }
    }
    return found;
}

function whatsApp(ctx, wa) {
    const found = [];
    const trustedSender = isTrustedWhatsApp(ctx.trusted, wa.senderNumber);
    if (trustedSender) ctx.notes.push(`The number ${wa.senderNumber} is on your trusted list, so contact checks were skipped. The message text was still checked.`);
    let number = wa.senderNumber.replace(/[\s()-]/g, '');
    if (number.startsWith('00')) number = '+' + number.substring(2);
    if (!trustedSender && number.startsWith('+') && !number.startsWith('+91') && number.length > 6) {
        found.push(ctx.indicator(R.WA_INTERNATIONAL_NUMBER, metadataEvidence('Sender: ' + wa.senderNumber),
            'The sender ' + wa.senderNumber + ' is an international number. Be very careful if you do not know this person.'));
    }
    if (wa.unknownContact && !trustedSender) {
        const ask = ctx.credentialRequest() ?? ctx.find(P.MONEY_REQUEST) ?? ctx.untrustedUrls()[0]?.evidence ?? null;
        if (ask) found.push(ctx.indicator(R.WA_UNKNOWN_CONTACT_REQUEST, ask));
    }
    if (wa.forwardedManyTimes) {
        const e = ctx.find(P.FORWARD_LURE);
        if (e && (ctx.urls.length > 0 || ctx.has(P.PRIZE) || ctx.has(P.URGENCY))) found.push(ctx.indicator(R.WA_FORWARDED_LURE, e));
    }
    return found;
}

function upi(ctx, d) {
    const found = [];
    if (d.requestType === 'COLLECT_REQUEST' || d.requestType === 'AUTOPAY_MANDATE' || d.requestType === 'QR_PAYMENT') {
        const e = ctx.find(P.MONEY_INCOMING);
        if (e) found.push(ctx.indicator(R.UPI_COLLECT_DISGUISED, e, d.requestType === 'QR_PAYMENT'
            ? "This is a UPI payment QR code or link: paying it with your PIN sends money FROM your account, even though the note mentions '" + e.snippet + "'."
            : 'This is a ' + UPI_REQUEST_TYPES[d.requestType].toLowerCase() + ": approving it with your PIN sends money FROM your account, even though the note mentions '" + e.snippet + "'."));
        if (d.amount != null && Number(d.amount) >= LARGE_AMOUNT) {
            found.push(ctx.indicator(R.UPI_LARGE_REQUEST, metadataEvidence('Amount: Rs ' + d.amount),
                'The request is for Rs ' + d.amount + '. Check carefully who is asking and why.'));
        }
    }
    const vpa = d.payeeVpa;
    if (vpa && isTrustedUpi(ctx.trusted, vpa)) {
        ctx.notes.push(`The UPI ID ${vpa} is on your trusted list, so UPI ID checks were skipped.`);
    } else if (vpa) {
        const ev = metadataEvidence('UPI ID: ' + vpa);
        if (!VPA.test(vpa)) {
            found.push(ctx.indicator(R.UPI_INVALID_VPA, ev));
        } else {
            const bait = VPA_BAIT.exec(vpa.substring(0, vpa.indexOf('@')));
            if (bait) found.push(ctx.indicator(R.UPI_SUSPICIOUS_VPA, ev,
                "The UPI ID '" + vpa + "' contains '" + bait[0] + "' to look official. Genuine refunds never arrive as requests you must approve."));
        }
    }
    return found;
}

function email(ctx, d) {
    const found = [];
    const from = parseAddress(d.fromAddress);
    const fromEvidence = metadataEvidence('From: ' + d.fromAddress);
    if (from.domain && isTrustedEmailDomain(ctx.trusted, from.domain)) {
        ctx.notes.push(`Mail from ${from.domain} is on your trusted list, so sender checks were skipped. The message and attachments were still checked.`);
    } else if (from.domain) {
        const risky = ctx.requestsRiskyAction();
        const claimed = allBrands().filter(b => {
            const named = ctx.brands.some(m => m.brand === b) || b.mention.test(from.displayName) || b.mention.test(d.subject);
            return named && (!b.isGeneric || risky);
        });
        const imitated = imitatedBy(from.domain);
        if (FREE_MAIL.has(from.domain) && claimed.length > 0) {
            found.push(ctx.indicator(R.EMAIL_FREE_PROVIDER_BRAND, fromEvidence,
                'The email claims to be from ' + claimed[0].name + ' but was sent from a free ' + from.domain + ' mailbox.'));
        } else if (imitated) {
            found.push(ctx.indicator(R.EMAIL_LOOKALIKE_DOMAIN, fromEvidence,
                "The sender domain '" + from.domain + "' uses the name of " + imitated.name + ' but is not one of its official domains.'));
        } else if (!isTrustedHost(from.domain)) {
            const displayed = allBrands().find(b => !b.isGeneric && b.mention.test(from.displayName));
            if (displayed) found.push(ctx.indicator(R.EMAIL_DISPLAY_NAME_MISMATCH, fromEvidence,
                "The sender name says '" + from.displayName + "', but the address is on " + from.domain + ', which does not belong to ' + displayed.name + '.'));
        }
    }
    const attachment = ctx.find(P.RISKY_ATTACHMENT);
    if (attachment) {
        found.push(ctx.indicator(R.EMAIL_RISKY_ATTACHMENT, attachment));
    } else if (matchesMetadata(P.RISKY_ATTACHMENT, d.subject)) {
        found.push(ctx.indicator(R.EMAIL_RISKY_ATTACHMENT, metadataEvidence('Subject: ' + d.subject)));
    }
    if (matchesMetadata(P.SUBJECT_PRESSURE, d.subject)) {
        found.push(ctx.indicator(R.EMAIL_SUBJECT_PRESSURE, metadataEvidence('Subject: ' + d.subject)));
    }
    return found;
}

/** "Display Name <user@domain>" or a bare address. */
export function parseAddress(raw) {
    let value = (raw ?? '').trim();
    let displayName = '';
    const lt = value.indexOf('<'), gt = value.lastIndexOf('>');
    if (lt >= 0 && gt > lt) { displayName = value.substring(0, lt).replaceAll('"', '').trim(); value = value.substring(lt + 1, gt); }
    const at = value.lastIndexOf('@');
    return { displayName, domain: at >= 0 ? value.substring(at + 1).trim().toLowerCase() : '' };
}
