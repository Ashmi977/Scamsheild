/**
 * Regular expressions used by the text rules. They run on NormalizedText, are case-insensitive
 * and include common Hinglish phrasing and light obfuscation (for example "O.T.P" or "0TP").
 */

const p = source => new RegExp(source, 'is');

const MONEY = String.raw`(?:₹|\brs\.?|\binr\b|\brupees?\b)`;
const SECRET = String.raw`\b(?:o\.?\s?t\.?\s?p|[o0]tp|one[ -]?time[ -]?password|verification code|cvv|cvc|password|passcode|net ?banking (?:password|login)|m-?pin|upi\s*pin|atm\s*pin|card\s*pin|pin(?!\s?code))\b`;

export const SENTENCE_END = new RegExp(String.raw`(?<!\b(?:rs|no|mr|mrs|dr|st|vs|a/c))[.!?]+(?=\s|$)|\n+`, 'i');

/** A sentence that warns the reader rather than asking them for something. */
export const SAFETY = p(String.raw`\b(?:do not|don't|dont|never|avoid|nobody|no one|will not|won't|not)\b\W+(?:\w+\W+){0,4}?(?:share|reveal|disclose|give|ask|tell|enter|request|call)\w*\W+(?:\w+\W+){0,5}?(?:otp|pin|password|cvv|card|details|code|credentials)`
    + String.raw`|\b(?:do not|don't|dont|never)\s+share\s+(?:it|this (?:otp|code)|the (?:otp|code))\s+with\s+(?:anyone|anybody)\b`
    + String.raw`|\b(?:scam|fraud|security|phishing|cyber)\s+(?:alert|warning|awareness|tips?)\b|\bbeware\b|\bstay (?:safe|alert)\b`);
/** A genuine one-time-password delivery, e.g. "123456 is your OTP". */
export const OTP_DELIVERY = p(String.raw`\b(?:otp|one[ -]?time[ -]?password|verification code|code)\b\D{0,25}\b\d{4,8}\b|\b\d{4,8}\b\D{0,15}\bis (?:your|the) (?:otp|code|one[ -]?time password|verification code)\b`);

export const CREDENTIAL = p(String.raw`\b(?:share|send|provide|reveal|tell|give|enter|type|forward|confirm|verify|read out|bata\w*|bhej\w*|de do)\b.{0,45}` + SECRET
    + '|' + SECRET + String.raw`.{0,30}\b(?:required|needed|send|share|bata\w*|bhej\w*|forward)\b`);
export const UPI_RECEIVE = p(String.raw`\b(?:receive|get|claim|collect|accept)\b.{0,55}\b(?:upi\s*)?pin\b(?!\s?code)`
    + String.raw`|\b(?:enter|share|type)\b.{0,35}\bupi\s*pin\b.{0,55}\b(?:receive|refund|money|payment|cashback|credit|prize)\b`);
export const QR_DECEPTION = p(String.raw`\b(?:scan|open)\b.{0,35}\bqr(?: code)?\b.{0,70}\b(?:receive|refund|claim|collect|cashback|money|credit)\b`
    + String.raw`|\b(?:receive|refund|claim|collect|cashback)\b.{0,70}\b(?:scan|open)\b.{0,35}\bqr(?: code)?\b`);
export const SMALL_VERIFICATION = p(String.raw`\bpay\b\s*(?:just|only)?\s*` + MONEY + String.raw`\s?(?:1|2|5|10)(?:\.00)?\b.{0,60}\b(?:verify|verification|confirm|activate|unlock|receive|register)`
    + String.raw`|\b(?:verify|activate|confirm)\b.{0,40}\bpay\b.{0,15}` + MONEY + String.raw`\s?(?:1|2|5|10)\b`);
export const ACCIDENTAL_TRANSFER = p(String.raw`\b(?:sent|transferred|paid|credited)\b.{0,40}\b(?:by mistake|wrongly|accidentally|galti se)\b|\b(?:wrong|mistaken)\s+(?:transfer|transaction|payment|upi)\b`);
export const RETURN_REQUEST = p(String.raw`\b(?:return|refund|send (?:it |the money )?back|wapas)\b`);
export const ADVANCE_FEE = p(String.raw`\b(?:registration|processing|activation|advance|verification|security|customs|clearance|insurance|transfer|unlock(?:ing)?|withdrawal)\s+(?:fee|fees|charge|charges|deposit)\b`
    + String.raw`|\bpay\b.{0,40}\b(?:fee|charge|deposit)\b.{0,50}\b(?:claim|release|loan|prize|job|refund|parcel|reward|unlock|withdraw)\w*`);
export const KYC_THREAT = p(String.raw`\b(?:kyc|pan|aadhaa?r|account|a/c|card|sim|mobile number|wallet|khata)\b.{0,60}\b(?:expire[sd]?|suspend(?:ed)?|block(?:ed)?|freez(?:e|ed)|deactivat\w+|band ho\w*|terminate[sd]?)\b`
    + String.raw`|\b(?:urgent(?:ly)?|immediately|within \d+ ?(?:hours?|hrs?|minutes?|mins?)|turant)\b.{0,70}\b(?:kyc|pan|aadhaa?r|account|bank)\b`
    + String.raw`|\bkyc\b.{0,40}\b(?:pending|incomplete|expired|not updated|update (?:now|immediately))\b`);
export const DIGITAL_ARREST = p(String.raw`\bdigital(?:ly)? arrest\w*\b`
    + String.raw`|\b(?:cbi|police|cyber ?(?:cell|crime)|customs|narcotics|ncb|trai|crime branch|enforcement directorate)\b.{0,100}\b(?:arrest\w*|warrant|fir|case (?:registered|filed|against)|money laundering|illegal|drugs|seized|legal action)\b`
    + String.raw`|\b(?:parcel|package|courier)\b.{0,60}\b(?:drugs|narcotics|illegal|seized|fake passports?)\b|\b(?:arrest warrant|non[- ]bailable)\b`);
export const UTILITY = p(String.raw`\b(?:electricity|power|bijli|light|gas)\b.{0,60}\b(?:disconnect\w*|cut ?off|will be cut|katega|kat jayega)\b`);
export const UTILITY_PRESSURE = p(String.raw`\b(?:tonight|today|immediately|call|contact|officer|whatsapp|\d{1,2}[:.]\d{2}\s?(?:pm|am))\b`);
export const SECRECY = p(String.raw`\b(?:do not|don't|dont|never)\s+(?:tell|inform|share (?:this|it) with|discuss (?:this |it )?with)\s+(?:anyone|anybody|your family|family|the bank|bank|police|friends|parents|dad|mom|mum|papa|mummy)\b`
    + String.raw`|\bkeep (?:this|it) (?:confidential|secret)\b|\bkisi ko (?:mat|na|nahi) bata\w*`);
export const URGENCY = p(String.raw`\b(?:act now|urgent(?:ly)?|immediately|within \d+\s?(?:hours?|hrs?|minutes?|mins?)|last (?:chance|date|warning|reminder)|final (?:notice|warning)|expires? today|today only|turant|jaldi)\b`);
export const PRIZE = p(String.raw`\byou(?:'ve| have)? (?:won|been selected)\b|\bcongratulations\b.{0,60}\b(?:won|winner|selected|eligible|reward)\b`
    + String.raw`|\b(?:winner|lucky draw|lottery|jackpot|kbc|free (?:gift|recharge|iphone|laptop|scooty)|gift (?:card|voucher) worth|inaam|jeet\w*)\b|\bprize\b`);
export const JOB_TASK = p(String.raw`\b(?:part[- ]?time|work from home|home[- ]based|online)\s+(?:job|work|income|opportunity)\b`
    + String.raw`|\b(?:like|subscribe|rate|review)\w*\b.{0,40}\b(?:videos?|youtube|hotels?|products?|posts?|channels?)\b.{0,80}(?:\bearn|\bpaid\b|\bsalary|\bcommission|` + MONEY + ')'
    + String.raw`|\b(?:earn|income|salary)\b.{0,30}` + MONEY + String.raw`\s?\d[\d,]*.{0,25}\b(?:daily|per day|a day|per task|per hour|weekly)\b`
    + String.raw`|\b(?:prepaid|merchant|vip)\s+tasks?\b|\btask[- ]based\b`);
export const INVESTMENT = p(String.raw`\b(?:guaranteed|assured|fixed|risk[- ]free)\s+(?:returns?|profits?|income)\b|\bdouble (?:your|ur) (?:money|investment)\b`
    + String.raw`|\b(?:\d{2,3}\s?%|\d+x)\s+(?:returns?|profits?)\b.{0,30}\b(?:daily|weekly|monthly|in \d+ days?)\b`
    + String.raw`|\b(?:stock|share market|trading|crypto|forex|ipo|bitcoin)\b.{0,40}\b(?:tips?|group|signals?|vip|guaranteed|profit)\b.{0,60}\b(?:join|whatsapp|telegram|invest|deposit|link)\b`);
export const LOAN = p(String.raw`\b(?:instant|pre[- ]?approved|guaranteed|easy)\s+(?:personal\s+)?loan\b`
    + String.raw`|\bloan\b.{0,40}\b(?:approved|sanctioned)\b.{0,60}\b(?:without|no)\s+(?:documents?|cibil|credit (?:check|score)|verification)\b`);
export const FAMILY = p(String.raw`\b(?:this is my new number|my new number|new (?:phone|number)\b.{0,30}\b(?:mom|mum|dad|papa|mummy|beta|bro|brother|sister|didi|bhai|friend))\b`
    + String.raw`|\b(?:lost|broke|broken) my phone\b|\b(?:hi|hello)\s+(?:mom|mum|dad|mummy|papa)\b|\b(?:in (?:an? )?(?:accident|hospital)|stuck at (?:the )?airport)\b`);
export const MONEY_REQUEST = p(String.raw`\b(?:send|transfer|pay|need|lend)\b.{0,40}(?:` + MONEY + String.raw`|\bmoney\b|\bpaise\b|\bamount\b|\bupi\b|\bgpay\b|\bphonepe\b|\bpaytm\b)`);
export const UNKNOWN_APP = p(String.raw`\b(?:install|download|open|use)\b.{0,45}\b(?:apk|any ?desk|team ?viewer|quick ?support|rustdesk|airdroid|remote (?:access|desktop|control)|screen ?shar\w*)\b`
    + String.raw`|\bshare (?:your|the|ur) screen\b|\b[\w-]+\.apk\b`);
export const CALL_MOBILE = p(String.raw`\b(?:call|contact|whatsapp|dial|reach|message)\b.{0,40}(?:\+?91[\s-]?)?\b[6-9]\d{4}[\s-]?\d{5}\b`);
export const LINK_ACTION = p(String.raw`\b(?:click|tap|verify|update|claim|login|log in|sign in|pay|complete|activate|redeem|download|open the link|link below)\b`);
export const MONEY_INCOMING = p(String.raw`\b(?:refund|cashback|reward|prize|won|receive|received|credit(?:ed)?|bonus|lottery|gift)\b`);
export const FORWARD_LURE = p(String.raw`\b(?:free|scheme|yojana|recharge|subsidy|laptop|gift|prize|offer|government is giving|forward (?:this|to))\b`);
export const CHAT_GROUP_CONTEXT = p(String.raw`\b(?:job|task|earn|income|profit|invest\w*|trading|stock|crypto|returns?|salary|join)\b`);
export const RISKY_ATTACHMENT = p(String.raw`\b[\w-]+\.(?:exe|scr|apk|js|vbs|bat|cmd|msi|iso|img|html?|hta|lnk|zip|rar|7z)\b|\b(?:open|download|run)\b.{0,30}\battach\w*\b.{0,30}\b(?:enable (?:macros|content)|zip|html|password)\b`);
export const SUBJECT_PRESSURE = p(String.raw`\b(?:urgent|action required|suspend\w*|final notice|immediately|last warning|account (?:locked|blocked|on hold)|verify (?:now|your account)|password expir\w*|legal action|unusual (?:sign-?in|activity))\b`);

const globalCopies = new WeakMap();

/** First match of `pattern` in `text` starting at `from`, like Java's Matcher.find(int). */
export function findFrom(pattern, text, from) {
    let g = globalCopies.get(pattern);
    if (!g) { g = new RegExp(pattern.source, pattern.flags + 'g'); globalCopies.set(pattern, g); }
    g.lastIndex = from;
    return g.exec(text);
}
