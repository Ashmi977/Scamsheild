/**
 * Small offline list of organizations that scammers commonly imitate in India, with their official
 * domains and the fragments that appear in their registered SMS sender IDs. It is deliberately
 * incomplete: an unknown brand simply produces no brand-specific signal.
 */

/** Domain suffixes that only verified organizations can register. */
const RESTRICTED_SUFFIXES = ['gov.in', 'nic.in', 'bank.in', 'gov'];

const endsWithDomain = (host, domain) => host === domain || host.endsWith('.' + domain);

class Brand {
    constructor(name, mention, hostKeywords, officialDomains, smsHeaderKeys) {
        this.name = name;
        this.mention = new RegExp(mention, 'i');
        this.hostKeywords = hostKeywords;
        this.officialDomains = officialDomains;
        this.smsHeaderKeys = smsHeaderKeys;
    }

    isOfficialHost(host) { return this.officialDomains.some(d => endsWithDomain(host, d)); }

    /** True when the host borrows this brand's name without being one of its domains. */
    isImitatedBy(host) {
        if (this.hostKeywords.length === 0 || this.isOfficialHost(host) || isRestrictedHost(host)) return false;
        for (const token of host.split(/[.\-]/)) {
            for (const keyword of this.hostKeywords) {
                if (keyword.length >= 5 ? token.includes(keyword) : token === keyword || token.startsWith(keyword) || token.endsWith(keyword)) return true;
            }
        }
        return false;
    }

    matchesSmsHeader(header) {
        const upper = header.toUpperCase();
        return this.smsHeaderKeys.some(k => upper.includes(k));
    }

    get isGeneric() { return this.smsHeaderKeys.length === 0; }
}

const BRANDS = [
    new Brand('SBI', String.raw`\b(?:sbi|state bank(?: of india)?|yono)\b`, ['sbi', 'onlinesbi', 'yonosbi'], ['sbi.co.in', 'onlinesbi.sbi', 'sbi', 'sbicard.com'], ['SBI']),
    new Brand('HDFC Bank', String.raw`\bhdfc\b`, ['hdfc'], ['hdfcbank.com', 'hdfc.com'], ['HDFC']),
    new Brand('ICICI Bank', String.raw`\bicici\b`, ['icici'], ['icicibank.com', 'icici.com'], ['ICICI']),
    new Brand('Axis Bank', String.raw`\baxis bank\b`, ['axisbank'], ['axisbank.com'], ['AXIS']),
    new Brand('Kotak Mahindra Bank', String.raw`\bkotak\b`, ['kotak'], ['kotak.com'], ['KOTAK']),
    new Brand('Punjab National Bank', String.raw`\b(?:pnb|punjab national bank)\b`, ['pnb'], ['pnbindia.in'], ['PNB']),
    new Brand('Paytm', String.raw`\bpaytm\b`, ['paytm'], ['paytm.com', 'paytmbank.com', 'paytm.in'], ['PAYTM', 'PYTM']),
    new Brand('PhonePe', String.raw`\bphone ?pe\b`, ['phonepe'], ['phonepe.com'], ['PHONPE', 'PHNPE', 'PHONEPE']),
    new Brand('Google Pay', String.raw`\b(?:google pay|gpay|g pay)\b`, ['gpay', 'googlepay'], ['google.com', 'g.co'], ['GPAY', 'GOOGLE']),
    new Brand('Amazon', String.raw`\bamazon\b`, ['amazon', 'amzn'], ['amazon.in', 'amazon.com', 'amzn.in', 'amzn.to'], ['AMAZON', 'AMAZN', 'AMZN']),
    new Brand('Flipkart', String.raw`\bflipkart\b`, ['flipkart', 'flpkart'], ['flipkart.com', 'fkrt.it'], ['FLPKRT', 'FLIPKT', 'FKART', 'FLIPKART']),
    new Brand('Income Tax Department', String.raw`\b(?:income ?tax|it department|itr refund|tax refund)\b`, ['incometax', 'itr', 'itrefund'], ['incometax.gov.in'], ['ITDEPT', 'INCOME', 'ITDCPC']),
    new Brand('India Post', String.raw`\b(?:india ?post|speed ?post)\b`, ['indiapost', 'speedpost', 'ipost'], ['indiapost.gov.in'], ['INDPST', 'IPOST', 'INPOST']),
    new Brand('Reserve Bank of India', String.raw`\b(?:rbi|reserve bank)\b`, ['rbi'], ['rbi.org.in'], ['RBI']),
    new Brand('EPFO', String.raw`\b(?:epfo|provident fund|pf (?:account|balance|withdrawal))\b`, ['epfo', 'epfindia'], ['epfindia.gov.in'], ['EPFO', 'EPFOHO']),
    new Brand('Courier company', String.raw`\b(?:fedex|dhl|blue ?dart|delhivery|dtdc)\b`, ['fedex', 'dhl', 'bluedart', 'delhivery', 'dtdc'], ['fedex.com', 'dhl.com', 'bluedart.com', 'delhivery.com', 'dtdc.in', 'dtdc.com'], ['FEDEX', 'DHL', 'BLUDRT', 'DLVERY', 'DTDC']),
    new Brand('Electricity board', String.raw`\b(?:electricity (?:board|department|office|officer)|bescom|msedcl|mahavitaran|tneb|tangedco|bses|tata power|adani electricity|uppcl)\b`, [], [], ['BESCOM', 'MSEDCL', 'MAHAVT', 'TNEB', 'BSES', 'TPWR', 'ADANIE', 'UPPCL']),
    new Brand('Police / investigating agency', String.raw`\b(?:cbi|police|cyber ?(?:cell|crime)|customs|narcotics|ncb|trai|enforcement directorate|crime branch)\b`, [], [], []),
    new Brand('A bank or government body', String.raw`\b(?:bank|government|govt|ministry|department)\b`, [], [], []),
];

export function allBrands() { return BRANDS; }

export function isRestrictedHost(host) { return RESTRICTED_SUFFIXES.some(s => endsWithDomain(host, s)); }

/** True when the host belongs to a known brand or a restricted government/bank zone. */
export function isTrustedHost(host) { return isRestrictedHost(host) || BRANDS.some(b => b.isOfficialHost(host)); }

/** First brand whose name the host imitates, or null. */
export function imitatedBy(host) { return BRANDS.find(b => b.isImitatedBy(host)) ?? null; }
