/** Everything a rule needs to inspect one message: normalized text, sentences, links, brand mentions and weights. */
import { NormalizedText } from './normalized-text.js';
import { allBrands } from './brands.js';
import { analyzeUrls } from './url-analyzer.js';
import { EMPTY_TRUSTED, isTrustedLinkHost } from './trusted.js';
import * as P from './patterns.js';

export class AnalysisContext {
    constructor(input, weights, trusted = EMPTY_TRUSTED) {
        this.input = input;
        this.details = input.details;
        this.weights = weights;
        this.trusted = trusted;
        /** Plain-language notes about checks skipped because of the user's trusted lists. */
        this.notes = [];
        this.normalized = new NormalizedText(input.text);
        const value = this.text = this.normalized.value;

        this.safeChar = new Uint8Array(value.length);
        let anySafe = false;
        for (let start = 0; start < value.length;) {
            const end = P.findFrom(P.SENTENCE_END, value, start);
            let stop = end ? end.index + end[0].length : value.length;
            if (stop <= start) stop = value.length;
            if (P.SAFETY.test(value.substring(start, stop))) { this.safeChar.fill(1, start, stop); anySafe = true; }
            start = stop;
        }
        this.anySafetyLanguage = anySafe;
        this.urls = analyzeUrls(this.normalized, host => isTrustedLinkHost(trusted, host));
        const trustedHosts = [...new Set(this.urls.filter(u => u.userTrusted).map(u => u.host))];
        if (trustedHosts.length > 0) this.notes.push(`Links to ${trustedHosts.join(', ')} are on your trusted list, so their addresses were not checked.`);
        this.brands = [];
        for (const brand of allBrands()) {
            const m = brand.mention.exec(value);
            if (m) this.brands.push({ brand, evidence: this.normalized.evidence(m.index, m.index + m[0].length) });
        }
    }

    /** First match that is not inside a warning/awareness sentence such as "Never share your OTP"; null when none. */
    find(pattern) {
        for (let from = 0; from < this.text.length;) {
            const m = P.findFrom(pattern, this.text, from);
            if (!m) break;
            if (!this.safeChar[m.index]) return this.normalized.evidence(m.index, m.index + m[0].length);
            from = m.index + 1;
        }
        return null;
    }

    has(pattern) { return this.find(pattern) !== null; }

    /** Links that do not belong to a known organization or a government/bank-only domain. */
    untrustedUrls() { return this.urls.filter(u => !u.trusted); }

    mentionsBrand() { return this.brands.length > 0; }

    /** A real OTP message ("123456 is your OTP ... do not share it") rather than a request for one. */
    isOtpDelivery() { return this.anySafetyLanguage && P.OTP_DELIVERY.test(this.text); }

    credentialRequest() { return this.isOtpDelivery() ? null : this.find(P.CREDENTIAL); }

    /** The message asks the reader to do something risky: open an unknown link, share a secret, pay, install or call. */
    requestsRiskyAction() {
        return this.untrustedUrls().length > 0 || this.credentialRequest() !== null || this.has(P.KYC_THREAT) || this.has(P.ADVANCE_FEE)
            || this.has(P.UNKNOWN_APP) || this.has(P.CALL_MOBILE) || this.has(P.UPI_RECEIVE)
            || this.has(P.DIGITAL_ARREST) || this.has(P.UTILITY);
    }

    indicator(rule, evidence, explanation = rule.explanation) {
        return { code: rule.code, title: rule.title, explanation, weight: this.weights[rule.code], group: rule.group, evidence };
    }
}

/** Matches a pattern against a short metadata value (sender, subject) rather than the message body. */
export function matchesMetadata(pattern, value) {
    return value != null && pattern.test(new NormalizedText(value).value);
}
