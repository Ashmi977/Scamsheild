// Enums and the rule catalogue, ported from the Java model package and RuleDefinition.

export const MAX_LENGTH = 10_000;

/** Channel a message arrived on. Each channel has its own metadata and channel-specific rules. */
export const SOURCES = {
    SMS: { name: 'SMS', description: 'Text message with a sender ID or phone number' },
    WHATSAPP: { name: 'WhatsApp', description: 'Chat message from a WhatsApp contact or unknown number' },
    UPI: { name: 'UPI request', description: 'UPI collect request, AutoPay mandate, or payment note' },
    EMAIL: { name: 'Email', description: 'Email with a sender address and subject' },
};

export const CATEGORIES = ['LOW', 'MEDIUM', 'HIGH', 'CRITICAL'];

/** The most likely scam pattern. Key order matters: ties are resolved in favour of the earlier entry. */
export const SCAM_TYPES = {
    NONE: 'No specific scam pattern',
    SUSPICIOUS: 'General suspicious message',
    KYC_PHISHING: 'KYC / account-block phishing',
    CREDENTIAL_THEFT: 'OTP / password theft',
    UPI_FRAUD: 'UPI payment fraud',
    REMOTE_ACCESS: 'Remote-access / malicious app',
    LOTTERY_PRIZE: 'Lottery / prize / cashback lure',
    JOB_TASK: 'Part-time job / task scam',
    INVESTMENT: 'Investment / trading scam',
    LOAN: 'Instant loan scam',
    DIGITAL_ARREST: 'Digital arrest / authority threat',
    UTILITY_DISCONNECTION: 'Electricity / utility disconnection scam',
    FAMILY_IMPERSONATION: 'Friend or family impersonation',
    PHISHING_LINK: 'Phishing link',
};

/** Broad family an indicator belongs to; used for grouping and recommendations. */
export const GROUPS = {
    CREDENTIAL: 'Credential theft', PAYMENT: 'Payment trick', LINK: 'Risky link', PRESSURE: 'Pressure & threats',
    IMPERSONATION: 'Impersonation', LURE: 'Too-good-to-be-true lure', MALWARE: 'Malware / remote access', SENDER: 'Sender & channel',
};

export const UPI_REQUEST_TYPES = {
    UNKNOWN: 'Not specified',
    COLLECT_REQUEST: 'Collect / pay request',
    AUTOPAY_MANDATE: 'AutoPay mandate',
    PAYMENT_NOTE: 'Payment received note',
    /** Extension-only: a scanned UPI QR code or upi://pay link. Paying it debits the user, like a collect request. */
    QR_PAYMENT: 'QR code / payment link',
};

function rule(weight, group, scamType, channel, title, explanation) {
    return { weight, group, scamType, channel, title, explanation };
}

/**
 * Every detection rule: default weight, group, the scam pattern it points to (null = generic) and the
 * channel it applies to (null = all channels).
 */
export const RULES = {
    // ---- Text rules: apply to every channel ----
    CREDENTIAL_REQUEST: rule(25, 'CREDENTIAL', 'CREDENTIAL_THEFT', null, 'Sensitive credential request',
        'The message asks for an OTP, password, CVV or PIN. Banks, apps and officials never ask for these by message or call.'),
    UPI_RECEIVE_PIN: rule(35, 'PAYMENT', 'UPI_FRAUD', null, 'UPI PIN to receive money',
        'Entering a UPI PIN always authorizes a payment from your account; it is never needed to receive money or a refund.'),
    QR_PAYMENT_DECEPTION: rule(25, 'PAYMENT', 'UPI_FRAUD', null, 'QR code to receive money',
        'Scanning a QR code is used to pay, not to receive money. A QR code offered for a refund or prize will debit you.'),
    SMALL_VERIFICATION_PAYMENT: rule(20, 'PAYMENT', 'UPI_FRAUD', null, "Small 'verification' payment",
        "Asking for a small payment (Rs 1, Rs 10) to 'verify' or 'activate' something is used to capture your PIN or start a larger fraud."),
    ACCIDENTAL_TRANSFER: rule(25, 'PAYMENT', 'UPI_FRAUD', null, "'Sent by mistake, please return' request",
        'Scammers claim they sent money by mistake and ask you to return it, often after a fake credit SMS or a stolen-fund transfer.'),
    ADVANCE_FEE: rule(20, 'PAYMENT', null, null, 'Advance-fee request',
        'The message asks for a fee before a promised refund, prize, job, loan, parcel or release of funds.'),
    KYC_URGENT_THREAT: rule(22, 'PRESSURE', 'KYC_PHISHING', null, 'Urgent KYC or account-block threat',
        'Threats that your account, card, SIM or KYC will be blocked are used to rush you into clicking or sharing details.'),
    DIGITAL_ARREST: rule(35, 'PRESSURE', 'DIGITAL_ARREST', null, "Police / agency threat ('digital arrest')",
        'Messages claiming police, CBI, customs or TRAI action, illegal parcels or arrest warrants are a common extortion script. Agencies do not arrest or settle cases over calls or chat.'),
    UTILITY_DISCONNECTION: rule(25, 'PRESSURE', 'UTILITY_DISCONNECTION', null, 'Electricity / utility disconnection threat',
        "Threats that your electricity or gas will be cut tonight unless you call an 'officer' are a well-known scam."),
    SECRECY_REQUEST: rule(12, 'PRESSURE', null, null, 'Asks you to keep it secret',
        'Being told not to tell family, the bank or police is a strong sign of social engineering.'),
    URGENCY_PRESSURE: rule(8, 'PRESSURE', null, null, 'Artificial urgency',
        "Short deadlines and 'act now' language are used to stop you from checking the claim."),
    PRIZE_OFFER: rule(18, 'LURE', 'LOTTERY_PRIZE', null, 'Prize, lottery or free-gift lure',
        'Unexpected prizes, lotteries, lucky draws and free gifts are common lures.'),
    JOB_TASK_OFFER: rule(25, 'LURE', 'JOB_TASK', null, 'Easy online job / task offer',
        "Offers to earn money by liking videos, rating hotels or doing 'tasks' usually end with you paying to 'unlock' earnings."),
    INVESTMENT_LURE: rule(25, 'LURE', 'INVESTMENT', null, 'Guaranteed-return investment lure',
        "Guaranteed or very high returns, VIP trading groups and 'double your money' offers are hallmarks of investment fraud."),
    LOAN_OFFER: rule(15, 'LURE', 'LOAN', null, 'Instant / no-document loan offer',
        'Instant loans without documents or credit checks are used to collect fees and personal data.'),
    FAMILY_EMERGENCY: rule(30, 'IMPERSONATION', 'FAMILY_IMPERSONATION', null, "'New number' or emergency money request",
        'Someone claiming to be a friend or relative on a new number and asking for money is a common impersonation scam.'),
    IMPERSONATION: rule(15, 'IMPERSONATION', null, null, 'Possible organization impersonation',
        'The message invokes a bank, payment app, courier or government body while demanding an action.'),
    CALLBACK_NUMBER: rule(12, 'IMPERSONATION', null, null, 'Asks you to call a personal mobile number',
        'Real customer care numbers are listed on official websites and apps; scammers put their own mobile number in the message.'),
    UNKNOWN_APP: rule(30, 'MALWARE', 'REMOTE_ACCESS', null, 'Unknown app or remote-access request',
        'Installing an APK or a screen-sharing app such as AnyDesk lets criminals see your OTPs and control your phone.'),

    // ---- Link rules: offline URL inspection ----
    APK_LINK: rule(30, 'MALWARE', 'REMOTE_ACCESS', null, 'Link downloads an Android app (.apk)',
        'Apps should only come from the Play Store or App Store. APK links in messages are a major source of banking malware.'),
    LOOKALIKE_DOMAIN: rule(30, 'LINK', 'PHISHING_LINK', null, 'Look-alike website address',
        'The link uses a known brand name in a domain that does not belong to that brand.'),
    SUSPICIOUS_URL: rule(20, 'LINK', 'PHISHING_LINK', null, 'Technically suspicious link',
        'The link has properties rarely used by genuine organizations.'),
    SHORT_LINK: rule(18, 'LINK', 'PHISHING_LINK', null, 'Shortened link',
        'Shortened URLs hide their real destination; verify independently before opening.'),
    PRESSURED_LINK: rule(12, 'LINK', 'PHISHING_LINK', null, 'Link with a pressured request',
        'A link paired with a request to click, verify, update or claim needs independent verification.'),
    CHAT_GROUP_LINK: rule(12, 'LINK', null, null, 'Invite to a WhatsApp / Telegram group',
        'Job and investment scams move victims into chat groups where fake profits are shown.'),

    // ---- SMS rules ----
    SMS_PHONE_SENDER_BRAND: rule(20, 'SENDER', null, 'SMS', 'Organization message from a personal number',
        'Banks, payment apps and government departments send SMS from registered sender IDs (for example AX-HDFCBK-S), not from 10-digit mobile numbers.'),
    SMS_PHONE_SENDER_LINK: rule(10, 'SENDER', null, 'SMS', 'Link sent from a personal number',
        'Unsolicited links from unknown mobile numbers are a common phishing route.'),
    SMS_HEADER_MISMATCH: rule(15, 'SENDER', null, 'SMS', 'Sender ID does not match the claimed organization',
        'The message claims to be from an organization whose name does not appear in the SMS sender ID.'),

    // ---- WhatsApp rules ----
    WA_INTERNATIONAL_NUMBER: rule(12, 'SENDER', null, 'WHATSAPP', 'International WhatsApp number',
        'Unsolicited WhatsApp messages from foreign numbers (job offers, investment tips) are a widespread scam pattern.'),
    WA_UNKNOWN_CONTACT_REQUEST: rule(10, 'SENDER', null, 'WHATSAPP', 'Unknown contact asks for money, codes or clicks',
        'A sender who is not in your contacts is asking you to pay, share a code or open a link.'),
    WA_FORWARDED_LURE: rule(12, 'SENDER', null, 'WHATSAPP', 'Viral forwarded offer',
        "'Forwarded many times' messages about free recharges, schemes or prizes are usually hoaxes or phishing."),

    // ---- UPI rules ----
    UPI_COLLECT_DISGUISED: rule(40, 'PAYMENT', 'UPI_FRAUD', 'UPI', 'Collect request disguised as money for you',
        'Approving a collect request or AutoPay mandate sends money FROM your account, even if the note says refund, cashback or prize.'),
    UPI_SUSPICIOUS_VPA: rule(18, 'SENDER', 'UPI_FRAUD', 'UPI', 'Suspicious UPI ID',
        'The UPI ID uses words like refund, reward, KYC or support to look official.'),
    UPI_INVALID_VPA: rule(10, 'SENDER', null, 'UPI', 'Malformed UPI ID',
        'The UPI ID is not in the normal name@bank format.'),
    UPI_LARGE_REQUEST: rule(10, 'PAYMENT', null, 'UPI', 'Large amount requested',
        'The request is for a large amount. Check carefully who is asking and why.'),

    // ---- Email rules ----
    EMAIL_FREE_PROVIDER_BRAND: rule(20, 'SENDER', null, 'EMAIL', 'Organization email from a free mailbox',
        'Banks and government departments do not send official mail from Gmail, Yahoo or Outlook addresses.'),
    EMAIL_LOOKALIKE_DOMAIN: rule(30, 'SENDER', null, 'EMAIL', 'Look-alike sender domain',
        "The sender's domain contains a brand name but is not that brand's official domain."),
    EMAIL_DISPLAY_NAME_MISMATCH: rule(15, 'SENDER', null, 'EMAIL', 'Display name does not match the sender domain',
        'The sender name claims an organization, but the address belongs to a different domain.'),
    EMAIL_RISKY_ATTACHMENT: rule(20, 'MALWARE', null, 'EMAIL', 'Risky attachment or file type',
        'Executable, script, HTML and archive attachments are often used to install malware or open fake login pages.'),
    EMAIL_SUBJECT_PRESSURE: rule(10, 'PRESSURE', null, 'EMAIL', 'High-pressure subject line',
        "Subjects such as 'Account suspended' or 'Final notice' are designed to make you act without checking."),
};
for (const [code, r] of Object.entries(RULES)) r.code = code;
Object.freeze(RULES);
