// Builds a ready-to-paste fraud report and a short shareable summary from an analysis.
// Nothing is submitted: the user copies the text and files it themselves on the official portals.
import { SCAM_TYPES, SOURCES, UPI_REQUEST_TYPES } from './engine/catalog.js';
import { inText } from './engine/normalized-text.js';

const CATEGORY_LABEL = { LOW: 'Low risk', MEDIUM: 'Medium risk', HIGH: 'High risk', CRITICAL: 'Critical risk' };

/** Official places to report, most urgent first, for the message's channel. */
export function reportDestinations(source, category) {
    const list = [];
    if (category === 'HIGH' || category === 'CRITICAL') {
        list.push({ title: 'Lost money or shared details?', text: 'Call the national cybercrime helpline 1930 immediately. The sooner you call, the better the chance of stopping the money.', href: 'tel:1930', label: 'Call 1930' });
    }
    list.push({ title: 'National Cyber Crime Reporting Portal', text: 'File a complaint about financial fraud or other cybercrime.', href: 'https://cybercrime.gov.in/', label: 'cybercrime.gov.in' });
    if (source === 'SMS' || source === 'WHATSAPP') {
        list.push({ title: 'Chakshu on Sanchar Saathi', text: 'Report suspected fraud SMS, calls and WhatsApp messages so the number can be investigated.', href: 'https://sancharsaathi.gov.in/', label: 'sancharsaathi.gov.in' });
    }
    if (source === 'UPI') list.push({ title: 'Your UPI app and bank', text: "Decline the request, then use the app's Report / Block option and inform your bank's official helpline.", href: null });
    if (source === 'EMAIL') list.push({ title: 'Your email provider', text: "Use 'Report phishing' in your mail app so similar emails are blocked for others too.", href: null });
    return list;
}

function detailLines(details) {
    switch (details.source) {
        case 'SMS': return [['Sender ID / number', details.senderId]];
        case 'WHATSAPP': return [['Sender number', details.senderNumber], ['Sender saved in contacts', details.unknownContact ? 'No' : ''],
            ['Marked "Forwarded many times"', details.forwardedManyTimes ? 'Yes' : '']];
        case 'UPI': return [['Request type', details.requestType !== 'UNKNOWN' ? UPI_REQUEST_TYPES[details.requestType] : ''],
            ['Payee UPI ID', details.payeeVpa], ['Amount', details.amount ? 'Rs ' + details.amount : '']];
        case 'EMAIL': return [['From', details.fromAddress], ['Subject', details.subject]];
    }
    return [];
}

/** Full plain-text report for a complaint form. */
export function buildReport(result, input, { includeMessage = true, checkedAt = new Date() } = {}) {
    const lines = [
        'SUSPECTED FRAUD MESSAGE: REPORT DETAILS',
        '',
        `Date and time checked: ${checkedAt.toLocaleString('en-IN', { dateStyle: 'medium', timeStyle: 'short' })}`,
        `Received via: ${SOURCES[result.source].name}`,
        ...detailLines(input.details).filter(([, v]) => v).map(([k, v]) => `${k}: ${v}`),
        '',
        `Assessment: ${CATEGORY_LABEL[result.category]} (${result.score}/100)` + (result.indicators.length ? `, likely ${SCAM_TYPES[result.scamType]}` : ''),
    ];
    if (result.indicators.length > 0) {
        lines.push('Warning signs found:');
        for (const i of result.indicators) {
            const ev = i.evidence.snippet ? (inText(i.evidence) ? ` (text: "${i.evidence.snippet}")` : ` (${i.evidence.snippet})`) : '';
            lines.push(`- ${i.title}${ev}`);
        }
    }
    if (includeMessage) lines.push('', 'Full message as received:', '"""', input.text.trim(), '"""');
    lines.push('', 'Prepared with ScamShield, an offline rule-based checker. The assessment is a warning, not proof. Keep the original message and screenshots as evidence.');
    return lines.join('\n');
}

/** Short text to warn friends or family, without the full message. */
export function buildSummary(result) {
    const top = result.indicators.slice(0, 3).map(i => i.title.replace(/\.$/, ''));
    const advice = result.recommendations.find(a => !a.startsWith('If you have already paid')) ?? result.recommendations[0];
    return [
        `ScamShield check: ${CATEGORY_LABEL[result.category]} (${result.score}/100)` + (result.indicators.length ? ` - looks like ${SCAM_TYPES[result.scamType]}.` : '.'),
        top.length ? `Warning signs: ${top.join('; ')}.` : 'No common scam patterns found, but stay careful.',
        `Advice: ${advice}`,
    ].join('\n');
}
