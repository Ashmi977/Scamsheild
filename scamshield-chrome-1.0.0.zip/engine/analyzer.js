/** Offline, rule-based analysis. Rules indicate risk; they do not prove fraud. */
import { MAX_LENGTH, RULES, SCAM_TYPES, SOURCES } from './catalog.js';
import { AnalysisContext } from './context.js';
import { SINGLE_RULES, detectChannel } from './rules.js';

export const DISCLAIMER = 'This score is a heuristic estimate based on the message and the details you entered. It is not proof that a message is fraudulent or safe.';

/** When the key indicator is present, the listed indicators describe the same behaviour and are dropped to avoid double counting. */
const SUPERSEDES = [
    ['UPI_RECEIVE_PIN', ['CREDENTIAL_REQUEST']],
    ['APK_LINK', ['UNKNOWN_APP']],
    ['SHORT_LINK', ['PRESSURED_LINK']],
    ['LOOKALIKE_DOMAIN', ['PRESSURED_LINK']],
    ['KYC_URGENT_THREAT', ['URGENCY_PRESSURE']],
    ['DIGITAL_ARREST', ['URGENCY_PRESSURE']],
    ['UTILITY_DISCONNECTION', ['URGENCY_PRESSURE']],
    ['UPI_COLLECT_DISGUISED', ['QR_PAYMENT_DECEPTION', 'UPI_RECEIVE_PIN']],
];

const clean = v => (v == null ? '' : String(v).trim());

/** Details with every field left blank, for when only the text is known. */
export function emptyDetails(source) {
    switch (source) {
        case 'SMS': return { source, senderId: '' };
        case 'WHATSAPP': return { source, senderNumber: '', unknownContact: false, forwardedManyTimes: false };
        case 'UPI': return { source, requestType: 'UNKNOWN', payeeVpa: '', amount: null };
        case 'EMAIL': return { source, fromAddress: '', subject: '' };
    }
    throw new Error('Unknown channel: ' + source);
}

/**
 * Validates and cleans the analyzer input, like the Java MessageInput record.
 * @throws Error with a user-facing message when the input cannot be analyzed
 */
export function createInput(source, text, details) {
    if (!SOURCES[source]) throw new Error('Unknown channel: ' + source);
    if (text == null || text.trim().length === 0) throw new Error('Enter a message before analyzing it.');
    if (text.length > MAX_LENGTH) throw new Error('Messages longer than ' + MAX_LENGTH + ' characters cannot be analyzed.');
    const d = { ...emptyDetails(source), ...(details ?? {}) };
    if (d.source !== source) throw new Error('Details for ' + d.source + ' cannot be used with ' + source);
    switch (source) {
        case 'SMS': d.senderId = clean(d.senderId); break;
        case 'WHATSAPP': d.senderNumber = clean(d.senderNumber); d.unknownContact = !!d.unknownContact; d.forwardedManyTimes = !!d.forwardedManyTimes; break;
        case 'UPI': d.requestType = d.requestType || 'UNKNOWN'; d.payeeVpa = clean(d.payeeVpa); d.amount = d.amount == null || d.amount === '' ? null : String(d.amount); break;
        case 'EMAIL': d.fromAddress = clean(d.fromAddress); d.subject = clean(d.subject); break;
    }
    return { source, text, details: d };
}

/**
 * Parses an amount typed by the user ("4,999", "₹ 250.50"). Returns the plain decimal string, or null when blank.
 * @throws Error when it is not a non-negative number
 */
export function parseAmount(raw) {
    const text = clean(raw).replaceAll(',', '').replaceAll('₹', '').trim();
    if (text === '') return null;
    if (!/^\+?(?:\d+\.?\d*|\.\d+)$/.test(text)) throw new Error('Enter the UPI amount as a number, for example 2500.');
    return text.replace(/^\+/, '');
}

export function defaultWeights(overrides = {}) {
    const weights = {};
    for (const [code, rule] of Object.entries(RULES)) weights[code] = rule.weight;
    for (const [code, value] of Object.entries(overrides)) {
        if (code in weights && Number.isInteger(value) && value >= 0) weights[code] = value;
    }
    return weights;
}

export function classify(score) {
    if (score <= 24) return 'LOW';
    if (score <= 49) return 'MEDIUM';
    if (score <= 74) return 'HIGH';
    return 'CRITICAL';
}

/**
 * Picks the scam pattern with the most indicator weight behind it. A generic phishing-link pattern
 * is only reported when nothing more specific was found.
 */
export function scamType(indicators) {
    if (indicators.length === 0) return 'NONE';
    const totals = new Map();
    for (const i of indicators) {
        const type = RULES[i.code].scamType;
        if (type) totals.set(type, (totals.get(type) ?? 0) + i.weight);
    }
    if (totals.size > 1) totals.delete('PHISHING_LINK');
    let best = null;
    for (const type of Object.keys(SCAM_TYPES)) {
        if (totals.has(type) && (best === null || totals.get(type) > totals.get(best))) best = type;
    }
    return best ?? 'SUSPICIOUS';
}

/** Turns detected indicators into concrete, channel-appropriate safety advice. */
export function recommend(source, category, type, indicators) {
    const advice = new Set();
    if (indicators.length === 0) {
        advice.add('No common scam patterns were found in this text, but that does not prove it is safe.');
        advice.add('Be cautious with any unexpected request for money, codes, app installs or personal details.');
        return [...advice];
    }
    if (category === 'HIGH' || category === 'CRITICAL') {
        advice.add('If you have already paid or shared details, call the cybercrime helpline 1930 immediately and report at cybercrime.gov.in.');
    }
    const byType = {
        DIGITAL_ARREST: "There is no 'digital arrest'. Police and agencies never investigate, arrest or collect money over video calls or chat. Hang up.",
        FAMILY_IMPERSONATION: 'Call the person on the number you already have for them before sending any money.',
        JOB_TASK: 'Genuine employers never ask you to pay to start work, unlock tasks or withdraw earnings.',
        INVESTMENT: 'Only invest through SEBI-registered brokers and apps; no one can guarantee returns.',
        UTILITY_DISCONNECTION: 'Check your bill status in the official electricity board app or website, not the number in the message.',
        LOAN: 'Borrow only from RBI-regulated banks/NBFCs, and never pay a fee before a loan is disbursed.',
    };
    if (byType[type]) advice.add(byType[type]);
    if (indicators.some(i => i.code === 'ACCIDENTAL_TRANSFER')) {
        advice.add('Check your real bank statement, not an SMS, before returning anything. If money truly arrived by mistake, ask the sender to contact their bank to reverse it.');
    }
    const groups = new Set(indicators.map(i => i.group));
    if (groups.has('CREDENTIAL')) advice.add('Do not share OTPs, passwords, CVVs or PINs. No bank, app or official will ever ask for them.');
    if (groups.has('PAYMENT')) advice.add('Receiving money never requires a UPI PIN, scanning a QR code or approving a request. Decline it.');
    if (groups.has('LINK')) advice.add('Do not open the link. Type the official website address yourself or use the official app.');
    if (groups.has('MALWARE')) advice.add('Do not install the app or open the file. If you already did, disconnect from the internet, uninstall it and contact your bank.');
    if (groups.has('IMPERSONATION')) advice.add('Contact the organization using the number on its official website, app or the back of your card, not one from the message.');
    if (groups.has('PRESSURE')) advice.add('Slow down. Real organizations do not threaten immediate blocking, arrest or disconnection by message.');
    if (groups.has('LURE')) advice.add('Unexpected prizes, jobs and guaranteed profits that need you to pay first are almost always scams.');
    advice.add({
        SMS: 'Report the SMS on the Sanchar Saathi portal (Chakshu) and delete it.',
        WHATSAPP: 'Block and report the sender in WhatsApp (open the chat, tap the name, then Block / Report).',
        UPI: "Decline the request in your UPI app and use the app's option to report or block that UPI ID.",
        EMAIL: "Use your email app's 'Report phishing' option. Do not reply, click links or open attachments.",
    }[source]);
    return [...advice];
}

/** Analyzes a validated input from createInput(). */
export function analyze(input, weights = defaultWeights()) {
    const ctx = new AnalysisContext(input, weights);
    const found = new Map();
    for (const rule of SINGLE_RULES) {
        const i = rule(ctx);
        if (i && !found.has(i.code)) found.set(i.code, i);
    }
    for (const i of detectChannel(ctx)) if (!found.has(i.code)) found.set(i.code, i);
    for (const [key, dropped] of SUPERSEDES) if (found.has(key)) dropped.forEach(code => found.delete(code));

    const indicators = [...found.values()].filter(i => i.weight !== 0).sort((a, b) => b.weight - a.weight);
    const score = Math.min(100, indicators.reduce((sum, i) => sum + i.weight, 0));
    const category = classify(score);
    const type = scamType(indicators);
    return {
        source: input.source, score, category, scamType: type, indicators,
        recommendations: recommend(input.source, category, type, indicators), disclaimer: DISCLAIMER,
    };
}
