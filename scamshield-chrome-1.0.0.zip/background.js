// Adds "Check with ScamShield" to the right-click menu for selected text. The selection is handed to the
// analyzer through session storage (memory only, cleared as soon as the analyzer reads it).

const MENU_ID = 'scamshield-check';

/** Picks the channel from the site the text was selected on; null keeps the user's last choice. */
function guessSource(pageUrl) {
    let host = '';
    try { host = new URL(pageUrl).hostname; } catch { return null; }
    if (host === 'web.whatsapp.com') return 'WHATSAPP';
    if (host === 'messages.google.com') return 'SMS';
    if (['mail.google.com', 'outlook.live.com', 'outlook.office.com', 'outlook.office365.com', 'mail.yahoo.com', 'mail.proton.me', 'mail.zoho.in', 'mail.zoho.com'].includes(host)) return 'EMAIL';
    return null;
}

chrome.runtime.onInstalled.addListener(() => {
    chrome.contextMenus.create({ id: MENU_ID, title: 'Check with ScamShield', contexts: ['selection'] });
});

chrome.contextMenus.onClicked.addListener(async (info, tab) => {
    if (info.menuItemId !== MENU_ID || !info.selectionText) return;
    await chrome.storage.session.set({ pending: { text: info.selectionText, source: guessSource(info.pageUrl ?? tab?.url ?? '') } });
    try {
        await chrome.action.openPopup();
    } catch {
        // openPopup is unavailable on older Chrome versions or without a focused window: use a tab instead.
        await chrome.tabs.create({ url: chrome.runtime.getURL('popup.html?mode=tab') });
    }
});
