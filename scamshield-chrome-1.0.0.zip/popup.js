import { CATEGORIES, GROUPS, MAX_LENGTH, SCAM_TYPES, SOURCES, UPI_REQUEST_TYPES } from './engine/catalog.js';
import { analyze, createInput, parseAmount } from './engine/analyzer.js';
import { inText } from './engine/normalized-text.js';
import { SAMPLES } from './samples.js';
import { clearHistory, loadHistory, saveResult, toCsv } from './history.js';

const $ = id => document.getElementById(id);
const chromeApi = globalThis.chrome?.storage ? globalThis.chrome : null;
const CATEGORY_LABEL = { LOW: 'Low risk', MEDIUM: 'Medium risk', HIGH: 'High risk', CRITICAL: 'Critical risk' };

let source = 'SMS';

function el(tag, props = {}, ...children) {
    const node = document.createElement(tag);
    for (const [key, value] of Object.entries(props)) {
        if (key === 'dataset') Object.assign(node.dataset, value);
        else if (key in node) node[key] = value;
        else node.setAttribute(key, value);
    }
    node.append(...children.filter(c => c != null));
    return node;
}

function setStatus(node, text, isError = false) {
    node.textContent = text;
    node.classList.toggle('error', isError);
}

// ---------------------------------------------------------------- Channel & form

function selectSource(next) {
    source = next;
    for (const b of $('channels').children) b.setAttribute('aria-pressed', String(b.dataset.source === next));
    for (const d of document.querySelectorAll('.details')) d.hidden = d.dataset.source !== next;
    $('channelDescription').textContent = SOURCES[next].description;
    const samples = $('samples');
    samples.replaceChildren(el('option', { value: '' }, `Try a ${SOURCES[next].name} sample…`),
        ...SAMPLES[next].map((s, i) => el('option', { value: String(i) }, s.label)));
    chromeApi?.storage.local.set({ lastSource: next });
}

function readDetails() {
    switch (source) {
        case 'SMS': return { source, senderId: $('smsSender').value };
        case 'WHATSAPP': return { source, senderNumber: $('waNumber').value, unknownContact: $('waUnknown').checked, forwardedManyTimes: $('waForwarded').checked };
        case 'UPI': return { source, requestType: $('upiType').value, payeeVpa: $('upiVpa').value, amount: parseAmount($('upiAmount').value) };
        case 'EMAIL': return { source, fromAddress: $('emailFrom').value, subject: $('emailSubject').value };
    }
}

function writeDetails(d) {
    selectSource(d.source);
    switch (d.source) {
        case 'SMS': $('smsSender').value = d.senderId; break;
        case 'WHATSAPP': $('waNumber').value = d.senderNumber; $('waUnknown').checked = d.unknownContact; $('waForwarded').checked = d.forwardedManyTimes; break;
        case 'UPI': $('upiType').value = d.requestType; $('upiVpa').value = d.payeeVpa; $('upiAmount').value = d.amount ?? ''; break;
        case 'EMAIL': $('emailFrom').value = d.fromAddress; $('emailSubject').value = d.subject; break;
    }
}

function clearForm() {
    for (const id of ['smsSender', 'waNumber', 'upiVpa', 'upiAmount', 'emailFrom', 'emailSubject', 'message']) $(id).value = '';
    $('waUnknown').checked = $('waForwarded').checked = false;
    $('upiType').value = 'UNKNOWN';
    $('samples').value = '';
    updateCounter();
}

function updateCounter() {
    const n = $('message').value.length;
    $('counter').textContent = `${n.toLocaleString('en-IN')} / ${MAX_LENGTH.toLocaleString('en-IN')}`;
    $('counter').classList.toggle('over', n > MAX_LENGTH);
}

// ---------------------------------------------------------------- Analysis

async function runAnalysis() {
    const status = $('status');
    let result, text;
    try {
        text = $('message').value;
        result = analyze(createInput(source, text, readDetails()));
    } catch (e) {
        setStatus(status, e.message, true);
        return;
    }
    renderResult(result, text);
    setStatus(status, 'Analysis complete. History stores only the channel, score, risk level, pattern and warning-sign names, never the message.');
    try {
        await saveResult(result);
    } catch (e) {
        setStatus(status, 'Analysis complete, but history could not be saved: ' + e.message, true);
    }
}

function renderResult(r, text) {
    const box = $('result');
    box.hidden = false;
    box.dataset.risk = r.category;
    drawGauge(r.score, r.category);
    $('category').textContent = CATEGORY_LABEL[r.category];
    $('pattern').textContent = r.indicators.length === 0 ? 'No scam pattern detected'
        : (r.category === 'LOW' ? 'Closest pattern: ' : 'Likely pattern: ') + SCAM_TYPES[r.scamType];

    $('indicatorCount').textContent = String(r.indicators.length);
    $('indicators').replaceChildren(...(r.indicators.length === 0
        ? [el('li', { className: 'empty-note' }, `No scam indicators were detected for this ${SOURCES[r.source].name} message.`)]
        : r.indicators.map(i => el('li', { className: 'indicator' },
            el('div', { className: 'head' }, el('span', { className: 'title' }, i.title), el('span', { className: 'weight', title: 'Points added to the score' }, `+${i.weight}`)),
            el('span', { className: 'group' }, GROUPS[i.group]),
            el('p', {}, i.explanation),
            i.evidence.snippet ? el('p', { className: 'evidence' }, inText(i.evidence) ? `Matched: “${i.evidence.snippet}”` : i.evidence.snippet) : null))));

    renderHighlights(text, r.indicators);
    $('advice').replaceChildren(...r.recommendations.map(a => el('li', {}, a)));
    $('disclaimer').textContent = r.disclaimer;
    if (!document.body.classList.contains('tab')) box.scrollIntoView({ behavior: 'smooth', block: 'start' });
}

/** Shows the original message with every matched range wrapped in <mark>; overlapping ranges are merged. */
function renderHighlights(text, indicators) {
    const ranges = indicators.filter(i => inText(i.evidence))
        .map(i => ({ start: i.evidence.start, end: i.evidence.end, titles: [i.title] }))
        .sort((a, b) => a.start - b.start);
    const merged = [];
    for (const r of ranges) {
        const last = merged.at(-1);
        if (last && r.start < last.end) { last.end = Math.max(last.end, r.end); last.titles.push(...r.titles); }
        else merged.push({ ...r });
    }
    $('highlightCard').hidden = merged.length === 0;
    const parts = [];
    let pos = 0;
    for (const r of merged) {
        parts.push(text.substring(pos, r.start), el('mark', { title: r.titles.join('\n') }, text.substring(r.start, r.end)));
        pos = r.end;
    }
    parts.push(text.substring(pos));
    $('highlighted').replaceChildren(...parts);
}

// ---------------------------------------------------------------- Gauge

const SVG = 'http://www.w3.org/2000/svg';
const svg = (tag, attrs) => { const n = document.createElementNS(SVG, tag); for (const [k, v] of Object.entries(attrs)) n.setAttribute(k, v); return n; };
const CX = 100, CY = 100, R = 80;
const point = (value, radius = R) => {
    const angle = Math.PI - (value / 100) * Math.PI;
    return [CX + radius * Math.cos(angle), CY - radius * Math.sin(angle)];
};

/** Semicircular 0-100 gauge with LOW / MEDIUM / HIGH / CRITICAL bands and a short needle. */
function drawGauge(score, category) {
    const g = $('gauge');
    g.replaceChildren();
    g.setAttribute('aria-label', score == null ? 'No score yet' : `Risk score ${score} out of 100, ${CATEGORY_LABEL[category]}`);
    const ends = [25, 50, 75, 100];
    let start = 0;
    CATEGORIES.forEach((cat, i) => {
        const [x1, y1] = point(start + (i ? 0.6 : 0)), [x2, y2] = point(ends[i] - (i < 3 ? 0.6 : 0));
        g.append(svg('path', {
            d: `M ${x1} ${y1} A ${R} ${R} 0 0 1 ${x2} ${y2}`, fill: 'none', 'stroke-width': 16,
            stroke: `var(--${cat.toLowerCase()})`, opacity: score == null || cat === category ? 1 : 0.22,
        }));
        start = ends[i];
    });
    if (score != null) {
        const [ox, oy] = point(score, R - 11), [ix, iy] = point(score, R - 36);
        g.append(svg('line', { x1: ix, y1: iy, x2: ox, y2: oy, stroke: 'var(--text)', 'stroke-width': 4, 'stroke-linecap': 'round' }));
    }
    const label = svg('text', { x: CX, y: CY - 4, 'text-anchor': 'middle', class: 'score', fill: category ? `var(--${category.toLowerCase()})` : 'var(--muted)' });
    label.textContent = score == null ? '—' : String(score);
    const t0 = svg('text', { x: CX - R, y: CY + 15, 'text-anchor': 'middle', class: 'tick' }); t0.textContent = '0';
    const t100 = svg('text', { x: CX + R, y: CY + 15, 'text-anchor': 'middle', class: 'tick' }); t100.textContent = '100';
    g.append(label, t0, t100);
}

// ---------------------------------------------------------------- History view

let historyItems = [];

async function refreshHistory() {
    try {
        historyItems = await loadHistory();
        setStatus($('historyStatus'), '');
    } catch (e) {
        historyItems = [];
        setStatus($('historyStatus'), 'History unavailable: ' + e.message, true);
    }
    renderHistory();
}

function renderHistory() {
    const all = historyItems;
    $('historyTotal').textContent = String(all.length);
    $('historyTotal').title = 'Total analyses';
    const max = Math.max(1, ...CATEGORIES.map(c => all.filter(i => i.category === c).length));
    $('categoryBars').replaceChildren(...CATEGORIES.map(c => {
        const n = all.filter(i => i.category === c).length;
        return el('div', { className: 'bar', dataset: { risk: c } },
            el('span', {}, CATEGORY_LABEL[c].replace(' risk', '')),
            el('span', { className: 'track' }, el('span', { className: 'fill', style: `width:${(n / max) * 100}%` })),
            el('span', { className: 'n' }, String(n)));
    }));
    $('sourceTotals').replaceChildren(...Object.entries(SOURCES).map(([key, s]) =>
        el('span', { className: 'chip' }, `${s.name} `, el('b', {}, String(all.filter(i => i.source === key).length)))));

    const fs = $('filterSource').value, fr = $('filterRisk').value;
    const shown = all.filter(i => (!fs || i.source === fs) && (!fr || i.category === fr));
    $('historyList').replaceChildren(...shown.map(i => el('li', {},
        el('span', { className: 'pill', dataset: { risk: i.category }, title: CATEGORY_LABEL[i.category] }, String(i.score)),
        el('div', {},
            el('div', { className: 'line1' }, el('strong', {}, SCAM_TYPES[i.scamType] ?? i.scamType),
                el('span', {}, `${SOURCES[i.source]?.name ?? i.source} · ${new Date(i.at).toLocaleString(undefined, { dateStyle: 'medium', timeStyle: 'short' })}`)),
            el('div', { className: 'inds', title: i.indicators }, i.indicators || 'No warning signs')))));
    $('historyEmpty').hidden = shown.length > 0;
    $('historyEmpty').textContent = all.length === 0
        ? 'No analyses yet. Results appear here after you analyze a message.' : 'No analyses match these filters.';
    $('exportCsv').disabled = shown.length === 0;
    $('clearHistory').disabled = all.length === 0;
}

function exportCsv() {
    const fs = $('filterSource').value, fr = $('filterRisk').value;
    const rows = historyItems.filter(i => (!fs || i.source === fs) && (!fr || i.category === fr));
    if (rows.length === 0) { setStatus($('historyStatus'), 'Nothing to export.'); return; }
    const url = URL.createObjectURL(new Blob([toCsv(rows)], { type: 'text/csv;charset=utf-8' }));
    const a = el('a', { href: url, download: `scamshield-history-${new Date().toISOString().slice(0, 10)}.csv` });
    document.body.append(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 10_000);
    setStatus($('historyStatus'), `Exported ${rows.length} row${rows.length === 1 ? '' : 's'}.`);
}

let confirmTimer;
async function onClearHistory() {
    const btn = $('clearHistory');
    if (!btn.classList.contains('confirm')) {
        btn.classList.add('confirm');
        btn.textContent = 'Click again to delete all';
        confirmTimer = setTimeout(() => { btn.classList.remove('confirm'); btn.textContent = 'Clear history'; }, 4000);
        return;
    }
    clearTimeout(confirmTimer);
    btn.classList.remove('confirm');
    btn.textContent = 'Clear history';
    try {
        await clearHistory();
        setStatus($('historyStatus'), 'History cleared.');
    } catch (e) {
        setStatus($('historyStatus'), 'Could not clear history: ' + e.message, true);
    }
    await refreshHistory();
}

// ---------------------------------------------------------------- Tabs & startup

function showView(name) {
    const analyzeView = name === 'analyze';
    $('tabAnalyze').setAttribute('aria-selected', String(analyzeView));
    $('tabHistory').setAttribute('aria-selected', String(!analyzeView));
    $('viewAnalyze').hidden = !analyzeView;
    $('viewHistory').hidden = analyzeView;
    if (!analyzeView) refreshHistory();
}

async function init() {
    if (new URLSearchParams(location.search).get('mode') === 'tab') document.body.classList.add('tab');

    $('channels').append(...Object.entries(SOURCES).map(([key, s]) =>
        el('button', { type: 'button', dataset: { source: key }, title: s.description, onclick: () => selectSource(key) }, s.name)));
    $('upiType').append(...Object.entries(UPI_REQUEST_TYPES).map(([k, v]) => el('option', { value: k }, v)));
    $('filterSource').append(el('option', { value: '' }, 'All channels'), ...Object.entries(SOURCES).map(([k, s]) => el('option', { value: k }, s.name)));
    $('filterRisk').append(el('option', { value: '' }, 'All levels'), ...CATEGORIES.map(c => el('option', { value: c }, CATEGORY_LABEL[c])));

    $('form').addEventListener('submit', e => { e.preventDefault(); runAnalysis(); });
    $('message').addEventListener('keydown', e => { if (e.key === 'Enter' && (e.ctrlKey || e.metaKey)) { e.preventDefault(); runAnalysis(); } });
    $('message').addEventListener('input', updateCounter);
    $('clear').addEventListener('click', () => { clearForm(); $('result').hidden = true; setStatus($('status'), 'Cleared.'); $('message').focus(); });
    $('samples').addEventListener('change', () => {
        const sample = SAMPLES[source][Number($('samples').value)];
        if (!sample || $('samples').value === '') return;
        clearForm();
        writeDetails(sample.details);
        $('message').value = sample.text;
        $('samples').value = String(SAMPLES[source].indexOf(sample));
        updateCounter();
        setStatus($('status'), `Loaded sample: ${sample.label}. Press Analyze.`);
    });
    $('tabAnalyze').addEventListener('click', () => showView('analyze'));
    $('tabHistory').addEventListener('click', () => showView('history'));
    $('filterSource').addEventListener('change', renderHistory);
    $('filterRisk').addEventListener('change', renderHistory);
    $('exportCsv').addEventListener('click', exportCsv);
    $('clearHistory').addEventListener('click', onClearHistory);
    $('openTab').addEventListener('click', () => {
        if (chromeApi) { chromeApi.tabs.create({ url: chromeApi.runtime.getURL('popup.html?mode=tab') }); window.close(); }
    });

    const { lastSource } = chromeApi ? await chromeApi.storage.local.get('lastSource') : {};
    selectSource(SOURCES[lastSource] ? lastSource : 'SMS');
    updateCounter();

    // Text sent from the right-click menu: read it once, then remove it from session storage.
    const { pending } = chromeApi?.storage.session ? await chromeApi.storage.session.get('pending') : {};
    if (pending?.text) {
        await chromeApi.storage.session.remove('pending');
        if (pending.source) selectSource(pending.source);
        $('message').value = pending.text;
        updateCounter();
        await runAnalysis();
    } else {
        $('message').focus();
    }
}

init();
